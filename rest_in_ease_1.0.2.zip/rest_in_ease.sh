#!/bin/bash

#args=$@

#curdir=`dirname $0`
JYTHON_HOME=/opt/jython2.5.2
${JYTHON_HOME}/bin/jython rest_in_ease.py $@
