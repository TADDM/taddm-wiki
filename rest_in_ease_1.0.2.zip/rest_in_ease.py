#!/usr/bin/env jython
import sys 
import math
import trace
import urllib
import urllib2
import getopt
import string
import base64
import httplib
import os
import re
import time
import calendar
import socket



from urlparse import urlparse
from getopt import GetoptError
#from datetime import date, datetime
#from java.io import IOException
#from locale import format_string
#from traceback import format_list
#from pprint import pprint
#from cgi import print_form
#from symbol import for_stmt

class structure:
    def __init__(self):
        self.instances = []
        return

    def add(self, instanceName):
        _name_ = "structure.add"
        traceit(">>> " + _name_)
        if not instanceName in self.instances:
            self.instances.append(instanceName)
        traceit("<<< " + _name_)
            
        return True
        
    def find(self, instanceName):
        _name_ = "structure.find"
        traceit(">>> " + _name_)
        ret = None
        for _i_ in self.instances:
            if _i_._instanceName_ == instanceName:
                ret = _i_
        traceit("<<< " + _name_)
        return ret

    def enum(self):
        _name_ = "structure.enum"
        traceit(">>> " + _name_)
        traceit("<<< " + _name_)
        return self.instances

    def count(self):
        _name_ = "structure.count"
        traceit(">>> " + _name_)
        traceit("<<< " + _name_)
        return len(self.instances)

    def remove(self, _resource_):
        _name_ = "structure.remove"
        traceit(">>> " + _name_)
        
        if _resource_ in self.instances:
            self.instances.remove(_resource_)
            
        traceit("<<< " + _name_)
        return
    
    def exist(self, instanceName):
        _name_ = "structure.exist"
        traceit(">>> " + _name_)
        traceit("<<< " + _name_)

        if instanceName in self.instances:
            return True
        else: 
            return False
        
    

class attribute:
    def __init__(self, attrName, metadata, className):
        _name_ = "attribute.__init__"
        traceit(">>> " + _name_)
        
        self._instanceName_ = attrName
        self.name = attrName
        self.usedBy = [className]
        if not attributes.exist(self):
            attributes.add(self)
        
        
        if metadata.has_key("length"):
            self.length = metadata["length"]
        if metadata.has_key("timestampType"):
            self.timestampType = metadata["timestampType"]
        if metadata.has_key("column"):
            self.column = metadata["column"]
        if metadata.has_key("displayString"):
            self.displayString = metadata["displayString"]
        if metadata.has_key("_class"):
            self._class = metadata["_class"]
        if metadata.has_key("type"):
            self.type = metadata["type"]
        if metadata.has_key("arrayType"):
            self.arrayType = metadata["arrayType"]
        if metadata.has_key("name"):
            self.name = metadata["name"]
        if metadata.has_key("relationshipType"):
            self.relationshipType = metadata["relationshipType"]
        if metadata.has_key("reverseRelationship"):
            self.reverseRelationship = metadata["reverseRelationship"]
        if metadata.has_key("table"):
            self.table = metadata["table"]
        if metadata.has_key("contained"):
            self.contained = metadata["contained"]
            
        traceit("<<< " + _name_) 
        return
    
    def get(self, attrName):
        _name_ = "attribute.get"
        traceit(">>> " + _name_)
        traceit("<<< " + _name_) 
        
        if attributes.query(attrName):
            return True
        else: 
            return False

    def gettype(self):
        _name_ = "attribute.gettype"
        traceit(">>> " + _name_)
        traceit("<<< " + _name_) 
        
        if self.type == None:
            return "None"
        else:
            return self.type

    def add_user(self, cls):
        _name_ = "attribute.add_user"
        traceit(">>> " + _name_)

        self.usedBy.append(cls)
        
        traceit("<<< " + _name_) 
        return 

        


class cdmclass:

    def __init__(self, className, resource):
        _name_ = "cdmclass.__init__"
        traceit(">>> " + _name_)

        self._instanceName_ = className
        self.name = className
        if cdmclasses.find(self.name) == None:
            cdmclasses.add(self)
        self.usedBy = [resource]
        self.attributeNames = self.set_attributes()

        traceit("<<< " + _name_)
        return
    
    def set_attributes(self):
        _name_ = "cdmclass.set_attributes"
        traceit(">>> " + _name_)
        
        clsAttr, clsMeta = get_class_metadata(self.name)
        self.attributes = []
        
        for attrName in clsAttr:
            attr = attributes.find(attrName)             
            if attr == None:
                attr = attribute(attrName, clsMeta[attrName], self)
            else:    
                attr.add_user(self)
            self.attributes.append(attr)

        traceit("<<< " + _name_)
        return self.attributes

    def get_attributes (self):
        _name_ = "cdmclass.get_attributes"
        traceit(">>> " + _name_)

        traceit("<<< " + _name_)
        return self.attributes

    def get_attributeNames(self):
        _name_ = "cdmclass.get_attributeNames"
        traceit(">>> " + _name_)

        attributeNames = []
        for a in self.attributes:
            attributeNames.append(a.name)
        
        traceit("<<< " + _name_)
        return attributeNames

    def add_user(self, cls):
        _name_ = "cdmclass.add_user"
        traceit(">>> " + _name_)

        self.usedBy.append(cls)
        
        traceit("<<< " + _name_)
        return 



class managementSystem:
    def __init__(self, guid, className, displayName):
#    def __init__(self,guid,className,displayName,resType):
        _name_ = "managementSystem.__init__" 
        traceit(">>> " + _name_)

        self._instanceName_ = guid
        self.name = displayName
#        self.type = resType
        self.className = className
        self.guid = guid
        self.values = {}
        self.displayName = displayName
        
        if managementSystems.find(self.className) == None:
            managementSystems.add(self)

        traceit("<<< " + _name_)
        return



class resource:
    def __init__(self, guid, className, displayName):
#    def __init__(self,guid,className,displayName,resType):
        _name_ = "resource.__init__" 
        traceit(">>> " + _name_)

        self._instanceName_ = guid
        self.name = displayName
#        self.type = resType
        self._class = className
        self.className = className
        self.guid = guid
        self.values = {}
        self.displayName = displayName
        
        if resources.find(self.className) == None:
            resources.add(self)
        self.set_attributes()

        traceit("<<< " + _name_)
        return

    def get(self):
        _name_ = "resource.get" 
        traceit(">>> " + _name_)
        traceit("<<< " + _name_)

        return {"guid":self.guid, "_class":self._class, "className":self.className, "displayName":self.displayName}    
#        return {"guid":self.guid,"_class":self._class,"className":self.className,"displayName":self.displayName,"type":self.type}    
        
    def get_attributes(self, attrName=None):
        _name_ = "resource.get_attributes" 
        traceit(">>> " + _name_)
        
        ret = None
        if attrName == None:
            ret = self.attributes    
        else:
            for _a_ in self.attributes:
                print str(_a_.instanceName)
                if _a_.instanceName == attrName:
                    ret = _a_
                    break 
            
        traceit("<<< " + _name_)
        return ret

        
    def set_attributes(self):
        _name_ = "resource.set_attributes" 
        traceit(">>> " + _name_)
        
        self._class = cdmclasses.find(self.className) 
        if self._class == None:
            self._class = cdmclass(self.className, self)
        else:
            self._class.add_user(self)
        self.attributes = self._class.get_attributes()
        
        traceit("<<< " + _name_)
        return

    def get_values(self, vals=None):
        _name_ = "resource.get_values" 
        traceit(">>> " + _name_)
        traceit("<<< " + _name_)
        
        if vals == None:
            return self.values    
        else:
            return self.values[vals]    

    def set_values(self):
        _name_ = "resource.set_values" 
        traceit(">>> " + _name_)
        
        self.values = get_guid_attributes(self.guid, self._class)

        traceit("<<< " + _name_)
        return 

    def delete(self):
        _name_ = "resource.delete" 
        traceit(">>> " + _name_)

        if resource_delete(self) == 0:
            #resources.remove(self)
            pass
        
        traceit("<<< " + _name_)
        return



class signature(structure):
    def __init__(self, json, query, _cls_):
        _name_ = "signature.__init__" 
        traceit(">>> " + _name_)
        
        self._instanceName_ = json
        self.displayName = ""
        self.values = {}
        self._class = _cls_
        self.className = _cls_
        self.json = json
        self.query = query
        self.processed = False
        self.matched = False
        self.matchedTo = []
        #self.guid=str(long(time.mktime(time.localtime())*1000) + signatures.count())
        self.guid="<to be assigned #" + str(signatures.count()) + ">"
        signatures.add(self)
        
        
        traceit("<<< " + _name_)        
        return
    
    def match(self, _resource_):
        _name_ = "signature.match" 
        traceit(">>> " + _name_)

        self.matchedTo.append(_resource_)
        self.matched = True
        
        traceit("<<< " + _name_)
        return resource

class update:
    def __init__(self, guid, resource, modification):
        _name_ = "update.__init__" 
        traceit(">>> " + _name_)
        
        self.modification = modification
        self._instanceName_ = guid
        self.guid = guid
        self.resource = resource
        self.attrib = {}
        updates.add(self)
        
        traceit("<<< " + _name_)        
        return
    
    def add(self, attrName, value):
        _name_ = "update.add" 
        traceit(">>> " + _name_)
        
        self.attrib[attrName] = value
        
        traceit("<<< " + _name_)
        return resource

class group:
    def __init__(self, guid, name, _class):
        _name_ = "group.__init__" 
        traceit(">>> " + _name_)
        
        self._instanceName_ = guid
        self.name = name
        self.guid = guid
        self._class = _class
        self.hasMembers = False
        self.members = {}
        self.processed = False
        groups.add(self)
        
        traceit("<<< " + _name_)        
        return
    
    def remove(self):
        _name_ = "group.remove" 
        traceit(">>> " + _name_)
   
        groups.remove(self)

        traceit("<<< " + _name_)
        
    def add_member(self, memberName, guid):
        _name_ = "group.add_member" 
        traceit(">>> " + _name_)
        
        self.members[memberName] = guid
        
        traceit("<<< " + _name_)
        return resource

    #
    #   Get the guid from a rest model object or query 
    #
    def get_members(self):
    
        _name_ = "group.get_members"
        traceit(">>> entering " + _name_)
    
        ##*******_memberType_ = groupTypes[self._class]
        
        
        try:
            # find the members
            _mbrType_=""
            _filter_ = "guid equals '" + self.guid + "'"
            
            #_url_, _query_ = build_query_url(_memberType_, None, self._class, _filter_, "query","only")
            _url_, _query_ = build_query_url("*", None, self._class, _filter_, "query", "only")
            
            rc = 0
            _res_ = []
            rc, _res_ = http_process(_url_, None, _query_, "GET", self._class)
        

            if rc == 0 and _res_ != "[]":    
                _lst_ = parse_json_list(_res_)

                for a in _lst_:
                    _dict_, rc = parse_json_string(a)
                    _mbr_ = []
                    for i in _dict_.keys():
                        if i in groupTypes:
                            _mbr_ = parse_json_list(_dict_[i])
                            _mbrType_ = i
                        
            traceit ("<<< " + _name_ , " returned: " + str(_mbr_))
        
            return _mbr_, _mbrType_
        
        except:
            logit ("Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            

            
'''
            if rc == 0 and _res_ != "[]":    
                _lst_ = parse_json_list(_res_)
                for a in _lst_:
                    _dict_, rc = parse_json_string(a)
                    if rc > 0:
                        raise Exit(4, "Problems parsing json in " + _name_)
                    if not  "members" in _dict_:
                        raise Exit(4,  _name_ + ": no members in " + g._class + " group '" + g.name + "'")
                        
                    _mbr_ = parse_json_list(_dict_["members"])
                    
                    for _m_ in _mbr_:
                        _dict_, rc = parse_json_string(_m_)
                        _attr_ = get_guid_attributes(_dict_["guid"], _dict_["_class"])
                        r = resource(_dict_["guid"], _dict_["_class"],_attr_["displayName"])


'''




class modification(structure):
    def __init__(self, resource, attribute, new_value, ignore, task):
        _name_ = "modification.__init__"
        traceit(">>> " + _name_)

        self.resource = resource
        self.attribute = attribute
        self.new_value = new_value
        if resource == None and task == "create":
            self.guid=""
            self.name="new"
        else:
            self.guid = str(resource.guid)
            self.name = str(resource.guid) + ":" + str(attribute.name)
        
        self.attrName = str(attribute.name)
        self.ignore = ignore
        self._instanceName_ = self.name
        self.task = task
        modifications.add(self)

        traceit("<<< " + _name_)
        return
    

    def view(self):
        _name_ = "modification.view"
        traceit(">>> " + _name_)

        print "resource  : " + str(self.resource)
        print "attribute : " + str(self.attribute) 
        print "new_value : " + str(self.new_value)
        print "name      : " + str(self.name)
        
        traceit("<<< " + _name_)
        return





class report:
    def __init__(self):
        _name_ = "report.__init__"
        traceit(">>> " + _name_)
        
        self.hdrLayout_equals_lneLayout = None
        self.hdrColSeq = None
        self.lneColSeq = None
        self.headers = []
        self.lines = []
        self.trailors = []
        self.maxLneLen = {}
        self.maxHdrLen = {}
        self.spaceChars = None
        traceit("<<< " + _name_)

    
    def add_header_format(self, _cols_, hdrLayout_equals_lneLayout=True):
        _name_ = "report.add_header_format"
        traceit(">>> " + _name_, str(_cols_) + ", " + str(hdrLayout_equals_lneLayout))

        self.hdrLayout_equals_lneLayout = hdrLayout_equals_lneLayout

        self.hdrColSeq = _cols_
        self.spaceChars = []
        self.maxHdrLen = {}
        self.hdrFormat = ""
        self.hdrColDelim = "   "
        #self.headers = []
        #self.lines = []
        #self.trailors = []
        
        self.hdrLen = 0
        for _h_ in self.hdrColSeq:
            self.maxHdrLen[_h_] = len(_h_)
            
        traceit("<<< " + _name_)
        return
    
    def add_header(self, _header_):
        _name_ = "report.add_header"
        traceit(">>> " + _name_, str(_header_))
        
         
        for _h_ in self.hdrColSeq:
            if self.maxHdrLen[_h_] < len(_header_[_h_]):
                self.maxHdrLen[_h_] = len(_header_[_h_])

        self.headers.append(_header_)
        traceit("<<< " + _name_)
        return

    def add_spacer(self, _spaceChar_):
        _name_ = "report.add_spacer"
        traceit(">>> " + _name_, str(_spaceChar_))
        self.spaceChars.append(_spaceChar_)
        self.lines.append(_spaceChar_)
        traceit("<<< " + _name_)
        return

    def add_line_format(self, _cols_):
        _name_ = "report.add_line_format"
        traceit(">>> " + _name_, str(_cols_))

        self.lneColDelim = "   "
        self.lneColSeq = _cols_
        self.lneLen = (len(self.lneColSeq) - 1) * len(self.lneColDelim)
        for _c_ in self.lneColSeq:
            self.maxLneLen[_c_] = len(_c_)
        self.lneFormat = ""
        
            
        
        traceit("<<< " + _name_)
        return

    def add_line(self, _line_):
        _name_ = "report.add_line"
        traceit(">>> " + _name_, str(_line_))
        
        for _l_ in self.lneColSeq:
            if self.maxLneLen[_l_] < len(_line_[_l_]):
                self.maxLneLen[_l_] = len(_line_[_l_])
        self.lines.append(_line_)

        traceit("<<< " + _name_)
        return


    def add_summary(self, _msg_):
        _name_ = "report.add_summary"
        traceit(">>> " + _name_, str(_msg_))

        self.trailors.append(_msg_)
        
        traceit("<<< " + _name_)
        return

    def printIt(self):    
        _name_ = "report.printIt"
        traceit(">>> " + _name_)

        if not resultOrderBy == None:
            to_be_sorted = []
            spacers = []
            for _l_ in self.lines:
                if len(str(_l_) )> 3:
                    if not  _l_.has_key(resultOrderBy):
                        raise Exit(8, "Invalid orderby column name: " + resultOrderBy)

                    to_be_sorted.append(_l_)
                else:
                    spacers.append(_l_)
                        
            newlines = sorted(to_be_sorted, key=lambda k: k[resultOrderBy])  
  
            self.lines = spacers + newlines
        
        
        
        if not self.hdrLayout_equals_lneLayout == None:
            if self.hdrLayout_equals_lneLayout == True:
 
                for i in self.maxHdrLen:
                    if self.maxLneLen[i] < self.maxLneLen[i]:
                        self.maxLneLen[i] = self.maxLneLen[i]

                if self.hdrLen > self.lneLen:
                    self.lneLen = self.hdrLen
                    self.maxLneLen = self.maxHdrLen
                else:
                    self.hdrLen = self.lneLen
                    self.maxHdrLen = self.maxLneLen

        
        if not self.maxLneLen == None:                 
            for i in self.maxLneLen:
                self.lneLen = self.lneLen + self.maxLneLen[i]
             
        if not self.maxHdrLen == None:                 
            for i in self.maxHdrLen:
                self.hdrLen = self.hdrLen + self.maxHdrLen[i]
             
        if not self.hdrColSeq == None: 
            i = 1
            for _h_ in self.hdrColSeq: 
                self.hdrFormat = self.hdrFormat + "%(" + _h_ + ")-" + str(self.maxHdrLen[_h_]) + "s" 
                if i < len(self.hdrColSeq):
                    self.hdrFormat = self.hdrFormat + str(self.hdrColDelim) 
                i = i + 1

        if not self.lneColSeq == None: 
            i = 1
            for _l_ in self.lneColSeq:
                self.lneFormat = self.lneFormat + "%(" + _l_ + ")-" + str(self.maxLneLen[_l_]) + "s"
                if i < len(self.lneColSeq):
                    self.lneFormat = self.lneFormat + self.lneColDelim 
                i = i + 1
                
        if not len(self.headers) == 0:
            if not string.lower(action) == "export":
                print >> outFileHandle, "" 
            for _h_ in self.headers:
                print >> outFileHandle, self.hdrFormat % _h_

        if not len(self.lines) == 0:
            for _l_ in self.lines:
                if not self.spaceChars == None:
                    if _l_ in self.spaceChars:
                        print >> outFileHandle, _l_ * self.lneLen
                    else:
                        print >> outFileHandle, self.lneFormat % _l_
                else:        
                    print >> outFileHandle, self.lneFormat % _l_

        if not len(self.trailors) == 0:
            for _t_ in self.trailors:
                print >> outFileHandle, _t_
        
        traceit("<<< " + _name_)
        return

class Quit(Exception):
    def __init__(self, rc=0,msg=None):
        _name_ = "Quit.__init__"
        traceit(">>> " + _name_)

        self.msg = msg
        self.rc = rc
        closeFiles()

        #traceit("<<< " + _name_)
        
        return
        

class Exit(Exception):
    def __init__(self, rc=0,msg=None):
        _name_ = "Exit.__init__"
        traceit(">>> " + _name_)

        self.msg = msg
        self.rc = rc

        traceit("<<< " + _name_)
        
    def printIt(self):
        _name_ = "Exit.printIt"
        traceit(">>> " + _name_)

        if not self.msg == None:
            logit(self.msg)
            #print >> errFileHandle, self.msg
        traceit("<<< " + _name_)
            
    def leave(self): 
        _name_ = "Exit.leave"
        traceit(">>> " + _name_)
        

#        if self.rc > 0: 
#            sys.exit()
        traceit("<<< " + _name_)
        
        closeFiles()
        raise SystemExit()

    
class Usage(Exception):
    def __init__(self, msg):
        
        _name_ = "Usage.__init__"
        traceit(">>> " + _name_)
        
        self.msg = msg

        traceit("<<< " + _name_)    



def show_help():
    '''
    '''
    _name_ = "show_Help"
    traceit(">>> " + _name_)

    print "\nSyntax:"
    print "    rest_in_ease.py      [COMMAND_OPTIONS] [TADDM_OPTIONS] [INPUT_OPTIONS] [RESOURCE_OPTIONS] [QUERY_OPTIONS] [ATTRIBUTE_OPTIONS] [REPORT_OPTIONS] [OUTPUT_OPTIONS] [MSSREGISTER_OPTIONS}"
    print ""
    print "      COMMAND_OPTIONS:     -a|--action {list | attr | export | update | create | modify | delete} [-f|--force] | -v|--version"
    print "" 
    print "      TADDM_OPTIONS:       -H|--host <hostname> -P|--port <port> -u|--user <username> -p|--password <password>"
    print "" 
    print "      INPUT_OPTIONS:       -i|--input <file_name>"
    print "" 
    print "      RESOURCE_OPTIONS:    [LIST_OPTIONS] [GROUP_OPTIONS] [GUID_OPTIONS] [TYPE_OPTIONS] -k|--combined"
    print '                              LIST_OPTIONS:  -L|--list <resourceType>{:"{"<attribute=value>{,<attribute:value>}*"}"}[,<resourceType>{:"{"[<attribute=value>{,<attribute=value>}*"}"]* | <file_name>'
    print "                            "
    print "                              GROUP_OPTIONS: -C|--groups {<GroupType:GroupName>{,<GroupType:GroupName>}* | <file_name>} [-m|--members groups | resources]"
    print "                            "
    print "                              GUID_OPTIONS:  -G|--guids <guid>{,<guid>}* | <file_name>"
    print "                            "
    print "                              TYPE_OPTIONS:  -T|--types <resourceType>{,<resourceType}* [-F|--filter <where_clause> | file_name] [-M|--mss <mss_guid>|<mss_name>][-D|--disctinct]"
    print "                            "
    print "      QUERY_OPTIONS:       [-S|--fetchsize <max resources>] [-Q|--depth <depth>]" 
    print "" 
    print "      ATTRIBUTE_OPTIONS:   -A|--attributes <attribute>[:<new_value>] {,<attribute>[:<new_value>]}* } | <file_name>" 
    print "" 
    print "      REPORT_OPTIONS:      [-c|--compact] [-g|--guid] [-n|--noguids] [-O|--orderby <orderBy>] [-s|--shortformat]"
    print "" 
    print "      OUTPUT_OPTIONS:      [-B|--banner] [-l|--log <logFile>]  [-o|--out <outFile>] [-e|--err <errFile>] [-d|--debug] [-t|--trace] [-h|--help] [-q|--quiet] " 
    print "" 
    print "      MSSREGISTER_OPTIONS: -R|--registermss [<mss_guid]> | <mss_name>"
    print "" 
    print ""
    print ""
    print "  Note:  Use the -I|--info option to see the details for all the valid arguments"
    print ""

    traceit("<<< " + _name_)    

def show_help_details():

    _name_ = "show_help_details"
    traceit(">>> " + _name_)

    
    print "\n      -a|--action <action>"
    print "            Valid actions are:"
    print "\n            list    Lists the guid, type, and displayName of the selected resources." 
    print "                    The resources to be listed are selected through the --list (-L), --groups (-C), --guids (-G), or --type (-T) arguments."
    print "                    If you also specify the --attributes (-A) argument, the list will be expanded with the attribute names listed in this argument. Values provided in the attribute option are ignored."
    print "                    You can also apply the --orderby (-O) argument to sort the list in ascending order of the selected attribute."
    print "\n            attr    Lists all available attributes for the selected resources."
    print "                    If you also provide the --attributes  (-A) argument, the list will be limited to the specified attributes."
    print "                    If you apply the --compact (-c) argument, only attributes that contains a value will be listed."
    print "                    If you provide the --shortformat (-s) argument class names will be displayed in the short format."
    print "\n            export  Exports the selected attributes to a flat file."
    print "                    The --compact (-c), --shortformat (-s), and --attributes (-A) arguments control the details that are exported  - similar to what applies to the attr action." 
    print "                    In addition, you can use the --guid (-g) argument to export a simple list of GUIDs."
    print "\n            update  Updates attributes for the selected resources."
    print "                    The --attribute (-A) argument is used to define values for attributes to be updated using the '<attribute>:<value> {, <attribute>:<value>}*' format."
    print "\n            create  Creates new resources in the TADDM database."
    print "                    To create new resources, you must specify the --list (-L), or --type (-T) arguments. If you use the --type argument the attributes and values must be specified "
    print "                    using the --attributes (-A) argument, and you must specify enough attribute:value pairs to support at lease one naming rule for the selected resource type."
    print "                    To automatically create the resources, apply the --force (-f) argument."
    print "\n            modify  Updates or creates resources in the TADDM database."
    print "                    Use the options similar to the update and create actions. Existing resources will be updated, and non-existing will be created."
    print "                    If you use the --force (-f) argument you will not be prompted to confirm updates, which enables using this facility from a script."
    print "\n            delete  Deletes resources from the TADDM database."
    print "                    Use this powerful option with extreme care. Resources to be deleted are identified using the --list (-L), --groups (-C), --guids (-G), or type (-T) options."
    print "                    If do not apply the --force (-f) argument, you will be prompted to confirm deletions."
    print "\n    -A|--attributes <attribute>[:<new_value>] {,<attribute>[:<new_value>]}* } | <file_name>"
    print "                       Specifies attributes, or attribute:value pairs to be used to control which attributes are listed/exported, and attribute values to be updated, or inserted."
    print "\n    -b|--basicauth     Uses header based HTTP authentication rather than the http authhandler class. Should only be enabled in Windows environments." 
    print "\n    -B|--banner        Show the input options"
    print "\n    -c|--compact       Prevents printing of attributes for which the value is null."
    print "\n    -C|--groups        A comma separated list of GroupType:GroupName pairs, or a reference to a file that contains a list of GroupType:GroupName pairs, "
    print "                       which is used to identify the members of the group(s) so they can be processed in one interaction." 
    print "                       Valid GroupTypes are BusinessSystem, Application,Collection, and AccessCollection."
    print "                       This option is handy if a workload has been moved to a different site, and the monitoring agents need to update TADDM to reflect the new configuration."
    print "\n    -d|--debug         Provides information helpful when debugging the tool."
    print "\n    -D|--distinct      Instructs the rest_in_ease tools to select ONLY resources of the specified type. Similar to the ONLY clause in MQL queries."
    print "                       If multiple used resource types are specified, the filter will be applied to each one individually, thus allowing you to create a report that contains "
    print "                       multiple resource types from single query. Naturally, all the resource types must support all the attributes used in the filter."
    print "\n    -e|--err           Allows you to write the error messages to a file."
    print "\n    -f|--force         Used to avoid being prompted for confirmation to apply updates. This option is only enforced for the update, create, modify and delete actions."
    print "\n    -F|--filter        Used to qualify the instances of the resource types you are selecting. The filter is used to build the where clause of a MQL query."
    print "\n    -g|--guidOnly      Forces the export action to export only the guids of the selected resources. Applies only to the export action."
    print "\n    -G|--guids         A comma separated list of guids, or a reference to a file that contains a list of guids, which is used to identify resources to process."
    print "\n    -h|--help          Provides online help information."
    print "\n    -H|--host          The hostname or IP address of the TADDM storage server you will connect to."
    print "\n    -i|--input <file name>"
    print "                       Reference to a file from which the tools reads input arguments. "
    print "                       Specify the file name according to the syntax of your operating system, and relative to the path from which the tool in invoked."
    print "\n    -I|--info        Show this list"
    print "\n    -k|--combined      If used, this flag will be used to combine resources from multiple options, thereby allowing you to produce a list of resources "
    print "                       from for example a list, a couple of guids, and specific resources identified by type and filter."
    print "\n    -l|--log <file name>"
    print "                       Allows you to write log information to a file. The file name provided is relative to the directory from which the tool is invoked."
    print '\n    -L|--list <resourceType>{:"{"<attribute=value>{,<attribute:value>}*"}"}[,<resourceType>{:"{"[<attribute=value>{,<attribute=value>}*"}"]* | <file_name>'
    print "                       Used to produce a list of resources based on a combination of attribute-value pairs. The may be read from a flat file, which can be populated using the export action."
    print "\n    -m|--members <groups|resources}"
    print "                       Used in conjunction with --groups to decide which resources to show. Specifies which type of group resources to include in the report. You can select members or groups. "
    print "                       If this argument is not specified, the report will show all group members." 
    print "\n    -M|--mss <mss_name>|<mss_guid>]"
    print "                       Use this argument in conjunction with the --type argument to select resources of the specified type that are registered with a specific management software system."
    print "\n    -n|--noguids       Applies only to the export action. Strips attributes such as guid, lastModifiedTime, lastModifiedBy, and type from the export data so they can be used "
    print "                       by the create, attr, or list actions without modification."
    print "\n    -o|--out <file name>"
    print "                       Allows you to direct the output of the tool directly to a file. This option is mainly used in conjunction with the export action."
    print "                       The file name is relative to the current directory."
    print "\n    -O|--orderby <orderBy>"    
    print "                       Sorts the output in ascending order of the selected attribute.This option is only used for the list and attr actions."
    print "\n    -p|--password <password>"
    print "                       Password for the user used to authenticate with the TADDM storage server."
    print "\n    -P|--port <port>   The port number you want to use for the connection to the TADDM storage server." 
    print "                       Default value is 9430."
    print "\n    -q|--quiet         Suppresses console messages."
    print "\n    -Q|--depth <depth>"    
    print "                       This integer controls the level of details from related resources that are collected from the TADDM database for each resource. The higher the number the more details. "
    print "                       The default value is 1."
    print "                       Use this option with extreme care. Gathering a lot of information about related resources may seriously impact the performance, and without providing a lot of benefit."
    print "\n    -R|--registermss [<mss_guid> | <mss_name>]"
    print "                       Specifies the MSS that will be registered as responsible for supplying the changes you apply. If this option is not specified, the changes will be registered with an MSS"
    print "                       named TADDM_Proactive_Update@<hostname>. If the mss_guid or mss_name has a value of 'None' (any case) no MSS registration will be performed. "
    print "                       If a MSS name or guid is specified, the changes will be registered with that MSS" 
    print "\n    -s|--shortformat   Forces the class names of to be printed in the short format."
    print "\n    -S|--fetchsize <max resources>"
    print "                       Determines the maximum number of records to process. Default value is 1."
    print "                       You should modify this option with care. Processing too may records may impact performance."
    print "                       This option does not apply if you use the --C|--groups option to list all descendants of a group object."
    print "\n    -t|--trace         Provides detailed information about the http calls performed by the tool."
    print "                       If used in combination with -d or --debug, this will also trace the data parsed from one routine to another."
    print "\n    -T|--types         A comma separated list of CDM class names of the resources types to select - or names of the resource types to include in a compound query."
    print "\n    -u|--user <username>"
    print "                       Name of the user used to authenticate with the TADDM storage server."    
    print "\n    -v|--vesion      Shows which vcersion of " + prog + " you are using."
    '''
    '''
    traceit("<<< " + _name_)    

    return 0
#
#  Log function
#  
def logit (_message_):  
    global lindent
    if not quiet:
        if string.find(_message_, ">>>") == 0:
            lindent = lindent + 1
        _pre_ = ""
        i = 0
        while  i < lindent:
            _pre_ = _pre_ + "\t"
            i = i + 1
                
        print _pre_ + _message_

        if string.find(_message_, "<<<") == 0:
            lindent = lindent - 1
    return



def traceit (_message_, _data_=None):
    global tindent
    if not debug:
        return
      
    if not quiet:
        if string.find(_message_, ">>>") == 0:
            tindent = tindent + 1
        _pre_ = ""
        i = 0
        while  i < tindent:
            _pre_ = _pre_ + "\t"
            i = i + 1
        
        if (not trace) or (_data_ == None):
            _data_ = ""
            
        print >> logFileHandle, _pre_ + _message_ + _data_

        if string.find(_message_, "<<<") == 0:
            tindent = tindent - 1
    return



######################

def basic_auth():
    _name_ = "basic_auth"
    traceit(">>> entering " + _name_)
        
    _httpUrl_ = taddmServerUrl + restUrl + "/ComputerSystem"
    ##_httpUrl_ = taddmServerUrl 
    _httpReq_ = urllib2.Request(_httpUrl_)
    _httpReq_.debuglevel = 1

    
    try:    
        _httpHandle_ = urllib2.urlopen(_httpReq_)
    except IOError, http_ex:
        if string.find(str(type(http_ex)), "URL") > 0:
            logit ('URL Reason: ' + str(http_ex.reason))
        elif string.find(str(type(http_ex)), "HTTP") > 0:
            if not  http_ex.code == 401:
                logit ('HTTP Code: ' + str(http_ex.code))
                raise Exit(http_ex.code, "HTTP Code")
        else:
            logit("Unexpected Error in " + _name_ + ": " + str(type(http_ex)) + " error while connecting to " + _httpUrl_)
            raise Exit(http_ex.code, "HTTP Code")
    else:        
        print str(http_ex)
        #print "No authentication necessary"
        if not hasattr(http_ex, 'code') or http_ex.code != 401:
            logit ("This page isn't protected by authentication.")
            logit ("But we failed for another reason.")
            raise Exit(4, "HTTP connection failed")

    if trace == True:
        print "==============================================================================================="
        print "curl -u " + taddmServerUser +":" + taddmServerPassword + " -i -X  GET "  + "\"" + _httpUrl_+"\"" 
        print "==============================================================================================="        
        inp = raw_input("Press Enter to continue..")


    
    authline = http_ex.headers.get("WWW-authenticate", "")
    if not authline:
        logit ("No header information available") 
        sys.exit(1)
    
    authobj = re.compile(r'''(?:\s*WWW-authenticate\s*:)?\s*(\w*)\s+realm=['"](\w+)['"]''', re.IGNORECASE)
    matchobj = authobj.match(authline)
    if not matchobj:   # if the authline isn't matched by the regular expression then something is wrong
        logit  ("The authentication line is badly formed.")
        sys.exit(1)

    scheme = matchobj.group(1) 
    taddmRealm = matchobj.group(2)
    

    if scheme.lower() != "basic":
        logit ("This example only works with BASIC authentication.")
        sys.exit(1)

    base64string = base64.encodestring('%s:%s' % (taddmServerUser, taddmServerPassword))[:-1]
    authheader = "Basic %s" % base64string
    
    _httpReq_.add_header("Authorization", authheader)
                     
    

    try:
        _httpReq_.debuglevel = 1
        _httpHandle_ = urllib2.urlopen(_httpReq_)

    except IOError, http_ex:                  # here we shouldn't fail if the username/password is right
        logit ("It looks like the username: '" + taddmServerUser + "' or password is wrong.")
        #sys.exit(1)
    else:
        pass
    
    _page_ = _httpHandle_.read()
    
    o = urlparse(str(_httpUrl_))
    _server_ = o[1].lower()   # _server_ names are case insensitive, so we will convert to lower case
    test = _server_.find(':')
    if test != -1: _server_ = _server_[:test]    # remove the :port information if present, we're working on the principle that realm names per _server_ are likely to be unique...


    passdict = {(_server_, taddmRealm) : authheader } # now if we get another 401 we can test for an entry in passdict before having to ask the user for a username/password

    traceit("<<< leaving " + _name_)

    return passdict, taddmRealm

    






################################
#
# Authenticate
#
def http_authenticate(http_url, taddmServerUser, taddmServerPassword, taddmServerHost, taddmServerPort):

    _name_ = "http_authenticate"
    traceit(">>> entering " + _name_)


    #"""
    #The proper way of actually doing all this is to use an HTTPBasicAuthHandler along with an HTTPPasswordMgr.
    #The python documentation on this is actually pretty minimal - so below is an example showing how to do this.
    #The main problem with HTTPPasswordMgr is that you must *already* know the realm - so we're going to use the HTTPPasswordMgrWithDefaultRealm instead !!
    #"""

    global httpOpener
    
    try:

        # this creates a password manager
        # passman = urllib2.HTTPPasswordMgrWithDefaultRealm()      
        #httpOpener = urllib2.build_opener(urllib2.HTTPHandler(debuglevel=1))

        rest_url=http_url+"/rest/model/meta/ComputerSystem"
        

        passman = urllib2.HTTPPasswordMgr()
        passman.add_password("taddm", http_url, taddmServerUser, taddmServerPassword)    
        authHandler = urllib2.HTTPBasicAuthHandler(passman)
        ##authHandler = urllib2.HTTPDigestAuthHandler(passman)
        
        if not trace:
            httpOpener = urllib2.build_opener(authHandler)
        else:
            httpOpener = urllib2.build_opener(authHandler, urllib2.HTTPHandler(debuglevel=1))
            
        
        #httpHandler = urllib2.HTTPHandler(debuglevel=1) 
        #httpOpener.add_handler(httpHandler)
        # you can use the opener directly to open URLs
        # *or* you can install it as the default opener so that all calls to urllib2.urlopen use this opener
        urllib2.install_opener(httpOpener)
        
        f = httpOpener.open(http_url)
        ##print f.read()
        f.close()        
        traceit("authenticated at " + http_url + " as " + taddmServerUser + " using " + taddmServerPassword)

        
        if trace == True:
            print "#####  authenticated at " + http_url + " as " + taddmServerUser + " using " + taddmServerPassword
            inp = raw_input("Press Enter to continue .................")
        
        traceit("<<< leaving " + _name_)

    
    except:
        raise Exit(4,"Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))

#
#
#
def regMss_delete(_guid_=None, _resourceType_="ManagementSoftwareSystem"):
    
    _name_ = "regMss_delete"
    traceit(">>> entering " + _name_)

    _query_ = {}
    try:
        
        if not _guid_ == None:
            _query_["delete"] = "true"
            _data_ = {"guid":_guid_, "_class":_resourceType_}
            _task_ = "DELETE"
            #if basicAuth == True:
            #    _url_ = restUrl + "/ModelObject" 
            #    _res_ = manipulate_modelobject(_url_,_data_,_query_,_task_)
            #else:    
            _url_ = restUrl + "/ModelObject"
            rc, _res_ = http_process(_url_, _data_, _query_, _task_)
                
        else:
            raise Exit(4,"Could not find object to delete")    
                
        traceit("<<< leaving " + _name_)
        
    except:
        raise Exit(4,"Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))

#
#
#
def regMss_create():
    
    _name_ = "regMss_create"
    traceit(">>> entering " + _name_)

    try:
                
        _resourceType_ = "ManagementSoftwareSystem"
        #_url_ = taddmModelUrl + "/" + _resourceType_
        #_url_ = restUrl + "/" + _resourceType_
        
        _url_, _query_ = build_query_url(None, None, _resourceType_, None, "create")
        _data_ = {}
        _data_["_class"] = _resourceType_
        _data_["MSSName"] = "TADDM_Proactive_Update@" + hostname
        _data_["productName"] = "TADDM"
        _data_["manufacturerName"] = "IBM"
        _data_["bidiFlag"] = 3
        _data_["hostname"] = hostname
        _data_["subcomponent"] = "Proactive"
        _data_["subcomponentInstanceName"] = progname
        #"displayName":"IBM:TADDM:192.168.80.132:Automation:Policy"     
        
        
        #if basicAuth == True:
        #    _res_ = manipulate_modelobject(_url_,_data_,_query_,"PUT")
        #else:    
            #_res_ = http_put(taddmServerUrl + _url_,_data_,_query_,_resourceType_)
        rc, _res_ = http_process(_url_, _data_, _query_, "PUT", _resourceType_)
        
        _regMss_ = None
        if rc == 0:
            _regMss_ = managementSystem(_res_, _data_["_class"], _data_["hostname"])
        traceit("<<< leaving " + _name_)
        return rc, _regMss_

    except:
        raise Exit(4,"Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))
        
#
#
#
def encode_data (_data_=None, _resourceType_=None):
    
    _name_ = "encode_data"
    traceit(">>> entering " + _name_, " : DATA: " + str(_data_) + ", resourceType: " + str(_resourceType_))

    _meta_ = None
    if not _resourceType_ == None:
        _attr_, _meta_ = get_class_metadata(_resourceType_)
    
    _json_ = ""
    if not _data_ == None:
        for d in _data_.keys():
            _type_ = "default"
            if not _meta_ == None:
                if d in _attr_:
                    _t_ = _meta_[d]
                    _type_ = _t_["type"]
            
            if not _json_ == "":
                _json_ = _json_ + ","  
            
                        
            _json_ = _json_ + '"' + d + '":'
            _typ_ = string.lower(_type_)
            if  (string.find(_typ_, "string") > 0) or (string.find(_typ_, "guid") > 0) or (_typ_ == "default") :
            ######## MMM   add support to set a value to NULL
            #if string.lower(_data_[d]) == "null":       
            #    _json_ = _json_ + '"NULL"'
            #else:                     
            #    ######## MMM
                _json_ = _json_ + '"' + str(_data_[d]) + '"'
            else:
                _json_ = _json_ + str(_data_[d])            
                         
        _json_ = "[{" + str(_json_) + "}]"
        
        
    traceit("<<< leaving " + _name_, " returning: " + str(_json_))
                  
    return (_json_)
#
#  get the http page
#
def manipulate_modelobject(_url_=None, _data_=None, _query_=None, _action_="GET", _resourceType_=None):
    
    _name_ = "manipulate_modelobject"
    traceit(">>> entering " + _name_, " : URL: " + str(_url_) + ", DATA: " + str(_data_) + ", QUERY: " + str(_query_) + ", ACTION: " + str(_action_))
    try:
        
        if not _query_ == None:
            _url_ = _url_ + "?" + urllib.urlencode(_query_)
        else:
            _query_ = ""
            
        if not _data_ == None:
            _data_ = encode_data(_data_, _resourceType_)
        else:
            _data_ = ""
        
        _headers_ = {} 
        _headers_["Authorization"] = passdict[taddmServerHost, taddmRealm]
        ##_headers_["Authorization"] = taddmServerUser + ":" + taddmServerPassword
        #_headers_["Content-Type"] = "application/x-www-form-urlencoded"
        _headers_["Content-Type"]= "application/json;charset=UTF-8"
        _headers_["Accept"] = "text/plain"
        
        taddmServerUri = taddmServerHost + ":" + taddmServerPort        
        
        _conn_ = httplib.HTTPConnection(taddmServerUri)
        
        traceit(_action_ + "ING: '" + _url_ , "'  data:'" + str(_data_) + "'")        
       
        if trace:
            _conn_.set_debuglevel(1)
            
        if _action_ == "DELETE":
            _conn_.request(_action_, _url_, None, _headers_)
        else:    
            _conn_.request(_action_, _url_, _data_, _headers_)
        #_conn_.request("POST", _url_, _data_, _headers_)
        
        _resp_ = _conn_.getresponse()

        
        rc = _resp_.status
        if rc == 200:
            rc = 0
        _page_ = None
        
        
        
        traceit("HTTP code:" + str(_resp_.status) + ", RC: " + str(_resp_.reason))
        
        
        if _resp_.status == 500:
            """
            logit ("\nHTTP Code: 500:   Could not read the resource.")
            logit ("\tAre you sure that you provided attributes to support at least one naming rule ??") 
            logit ("\tand that '" + resourceType + "' is a valid resource type ??")
            logit ("\n\tURL: " +  _url_ )
            """
            return rc, _page_
        
        _page_ = _resp_.read()
        
        if debug:
            if "meta" in _url_ > 0:
                f = open("meta_out.htm", "w")
            else:
                f = open("data_out.htm", "w")

            f.write(_page_)
            f.flush
            f.close
            
        traceit("<<< " + _name_ , " returned: " + str(_page_))
        
        if trace == True:
            print "==============================================================================================="
            print "curl -u " + taddmServerUser +":" + taddmServerPassword + " -i -X " + _action_ + " \"http://" + taddmServerHost +":"+taddmServerPort  + _url_ +"\"" 
            print "==============================================================================================="        
            inp = raw_input("Press Enter to continue..")



                
        return rc, _page_         
    
    except IOError, _httpEx_:
        
        if string.find(str(type(_httpEx_)), "URLError") > 0:
            logit ("Error while fetching " + _url_)
            logit ("URLError: " + str(_httpEx_.reason))
            sys.exit((str(_httpEx_.reason)))                     
        elif  string.find(str(type(_httpEx_)), "HTTPError") > 0:
            if _httpEx_.code == 400:
                logit ("(HTTP:400) Nothing found.")
                logit (_httpEx_.msg)                
            if _httpEx_.code == 401:
                logit ("(HTTP:401) Authentication with the taddm server failed.")
                raise Exit (401,"(HTTP:401) Authentication with the taddm server failed.") 
            elif _httpEx_.code == 500:
                logit ("(HTTP:500) The requested resource '" + str(_url_) + "' could not be found.")
                return _httpEx_.code
            else:
                logit (str(type(_httpEx_)) + ": code(" + str(_httpEx_.code) + ") while getting " + _url_)

        else:
            raise Exit(8,"Unexpected IOError: " + str(type(_httpEx_)) + "  " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]) + "\n" + str(type(_httpEx_)) + ": code(" + str(_httpEx_.code) + ") while getting " + _url_)
    except:
        raise Exit(8,"Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            
    
    



#
#  get the http page
#
def http_process(_url_=None, _data_=None, _query_=None, _task_="GET", _resourceType_=None):
    
    


                 
    _name_ = "http_process" 
    traceit (">>> entering " + _name_ + ": URL: " + str(_url_), ", DATA:" + str(_data_) + ", QUERY:" + str(_query_))
    try:
        rc = 0
        _httpPage_ = None
        
        if basicAuth == True:
            rc, _res_ = manipulate_modelobject(_url_,_data_, _query_, _task_, _resourceType_)
            traceit ("<<< " + _name_, " returned: " + str(rc) + ", " + str(_res_))

            return rc ,_res_
        else:
            _url_ = taddmServerUrl + _url_
        
        
        ##_query_ = urllib.urlencode(_query_)
        if not _query_ == None:
            _url_ = _url_ + "?" + str(urllib.urlencode(_query_))
 
        if not _data_ == None:
            _data_ = encode_data(_data_,_resourceType_)
        else:
            _data_ = ""
 
        traceit (_task_ + "ing:'" + str(_url_), "'   data:'" + str(_data_) + "'")

        _headers_ = {}
        _headers_["Content-Type"]= "application/json;charset=UTF-8"
        #_headers_["Content-Type"] = "application/x-www-form-urlencoded"
        #_headers_["Accept"] = "text/plain"
        
        if  string.upper(_task_) == "GET":     
            _httpOpen_ = urllib2.urlopen(_url_)
            _httpPage_ = _httpOpen_.read()
        else:
            
            _httpReq_ = urllib2.Request(_url_, _data_,_headers_)
            _httpReq_.get_method = lambda: string.upper(_task_)
            _httpHandle_ = httpOpener.open(_httpReq_)
            _httpPage_ = _httpHandle_.read()


        traceit ("<<< " + _name_, " returned: " + str(rc) + ", " + _httpPage_)

        if trace == True:
            print "==============================================================================================="
            print "curl -u " + taddmServerUser +":" + taddmServerPassword + " -i -X " + string.upper(_task_) + " \"http://" + taddmServerHost +":"+taddmServerPort  + _url_ +"\"" 
            print "==============================================================================================="        
            inp = raw_input("Press Enter to continue..")




        return rc, _httpPage_         
    
    except IOError, _httpEx_:
        
        print "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
        print str(_httpEx_.read())        
        print "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
        if string.find(str(type(_httpEx_)), "URLError") > 0:
            logit ("URLError: " + str(_httpEx_.reason))
            raise Exit(str(_httpEx_.reason),"Error while fetching " + _url_) 
        elif string.find(str(type(_httpEx_)), "HTTPError") > 0:
            if _httpEx_.code == 400:
                logit ("(HTTP:400) " +  _httpEx_.msg) 
            elif _httpEx_.code == 401:
                logit ("(HTTP:401) Authentication with the taddm server failed.")
                raise Exit ("(HTTP:401) Authentication with the taddm server failed.") 
            elif _httpEx_.code == 500:
                if not _task_ == "GET":
                    logit ("The server encountered an unexpected condition which prevented it from fulfilling the request.")
                    if _query_ == None:
                        _query_ = {"query":""}

                    logit ("The request was: '" + str(_task_) + " " + _url_ + "/" + str(_query_["query"]) + "'  parsing the following data: '" + str(_data_) + "'")
                    logit ("You might have supplied an invalid resourceType or unknown attributes, or not provided enough attributes to support a naming rule in case you are creating, updating, or modifying a resource") 
                    traceit (str(_httpEx_.code) + "  " + str(_httpEx_.msg))
                    return _httpEx_.code, _httpPage_
            else:
                logit (str(type(_httpEx_)) + ": code(" + str(_httpEx_.code) + ") while " + _task_ + "ing " + _url_)
            return _httpEx_.code, _httpPage_
        else:
            logit ("Unexpected IOError: " + str(type(_httpEx_)) + "  " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            
            logit (str(type(_httpEx_)) + ": code(" + str(_httpEx_.code) + ") while getting " + _url_)
            raise Exit(str(_httpEx_.code)," while getting " + _url_)
    #except:
        #logit ("Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            
        #raise Exit




#
#  parse the json results
#
def parse_json_list(_jsonString_):    
      
    _name_ = "parse_json_list"
    traceit (">>> entering " + _name_, _jsonString_)

    try:
        #
        
        _obj_ = _jsonString_

        if _obj_[0] == "[":
            _obj_ = _obj_[1:]
        if _obj_[len(_obj_) - 1] == "]":
            _obj_ = string.rstrip(_obj_, "]")
        #if _obj_[0] == "{":
        #    _obj_ = _obj_[1:]
        #if _obj_[len(_obj_) - 1] == "}":
        #    _obj_ = string.rstrip(_obj_, "}")
        
        #if string.find(_obj_,"{") > -1:
        #    _obj_ = _obj_ + "}"
            
        _lst_ = []
        a = ""
        splt = "},"
        for _l_ in string.split(_obj_, splt):
            a = a + _l_
            if not a[len(a)-1] == splt[0]:
                a = a + splt[0]

            _opens_ = string.count(a, "{")
            _closes_ = string.count(a, "}")
 
            if _opens_ == _closes_:
                a = "{" + a
                if not a[len(a)-1] == "}":
                    a =  a + "}"
                _lst_.append(a)
                
                
                a = "{" + a + "}"        
                _aopens_ = string.count(a, "[") 
                _bopens_ = string.count(a, "{")
                _acloses_ = string.count(a, "]") 
                _bcloses_ = string.count(a, "}")
            
                a = ""
            else:
                a = a + splt[1:] 
            
        traceit ("<<< leaving " + _name_)    
        return(_lst_)
    
    except:
        logit ("Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            
        raise Exit





#
#  parse the json results
#
def parse_json_string(_jsonString_, returnSequence=False):      
    _name_ = "parse_json_string"  
    traceit (">>> entering " + _name_ + ": ", _jsonString_)

    try:
        rc = 0
        _obj_ = _jsonString_
        if _obj_[0] == "[":
            _obj_ = string.strip(_obj_, "[")
        if _obj_[0] == "{":
            _obj_ = string.strip(_obj_, "{")
        if _obj_[len(_obj_) - 1] == "]":
            _obj_ = string.rstrip(_obj_, "]")
        if _obj_[len(_obj_) - 1] == "}":
            _obj_ = string.rstrip(_obj_, "}")
            
        _lst_ = []
        a = ""
        _wrk_ = string.split(_obj_, ",")


        do_it = False        
        for _w_ in _wrk_:    
            
            a = a + _w_
            _aopens_ = string.count(a, "[") 
            _bopens_ = string.count(a, "{")
            _acloses_ = string.count(a, "]") 
            _bcloses_ = string.count(a, "}")
            _quotes_ = float(string.count(a, '"'))
            _quotes2_ = float(_quotes_ / 2)
            ##print str(_aopens_) + "/" + str(_acloses_) + "  "  + str(_bopens_) + "/" + str(_bcloses_) + " - " + str(_quotes_) + "\t\t" + a 
             
                                
            if _aopens_ == _acloses_ and _bopens_ == _bcloses_:
                do_it = True
                 
            if do_it and _quotes2_ != math.floor(_quotes2_):
                do_it = False
                  
            if do_it == True:
                    _lst_.append(a)
                    a = ""
                    do_it = False
            else:
                a = a + "," 
            
        ## parse list into dictionary
        _dict_ = {}
        _seq_ = []

        for a in _lst_:
            
            
            
              
            if returnSequence:
                _seq_.append(string.strip(string.split(a, ":")[0], string.whitespace))
            _x_, _y_ = string.split(a, ":", 1)
       
            if string.find(_y_, '"') > -1:
                ## strip first and last doublequote                
                if _y_[0] == '"': 
                    _y_ = _y_[1:]
                if _y_[_y_.__len__()-1] == '"':   
                    _y_ = _y_[:-1]
                #$$$$ _y_ = _y_.replace('"',"'")
                
                _dict_[string.strip(string.strip(_x_, '"'), string.whitespace)] = string.strip(_y_, '"')
            else:
                _dict_[string.strip(string.strip(_x_, '"'), string.whitespace)] = _y_
        
        
        
    except:
        rc = 4
        logit ("Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            

    finally:

        traceit("<<< leaving " + _name_, str(_dict_))    
        if returnSequence:
            return(_dict_, rc , _seq_)
        else:
            return(_dict_, rc)
        
#
#  Read the http page using get
#  and return attributes in a dictionary
#    
def build_query_url(_attr_="*", _guid_=None, _resourceType_=None, _resourceFilter_=None, _task_="query", only="", orderBy=""):
        
    _name_ = "build_query_url"
    traceit (">>> entering " + _name_ , ": " + str(_attr_) + ", " + str(_guid_) + ", " + str(_resourceType_) + ", " + str(_resourceFilter_))


    try:    
        _query_ = {}
        _url_ = ""

        if orderBy == None:
            orderBy = ""
        else:
            if attributes.find(orderBy) == None:
                orderBy = ""
     
        if only == False:
            only = ""
        else:
            only = "ONLY"
     
        if orderBy == "_class":
            orderBy = ""
                    
        if _task_ == "meta":
            _url_ = restUrl + "/meta/" + _resourceType_
            _query_["feed"] = "json"

        elif _task_ == "discover":
            _id_ = calendar.timegm(time.gmtime())
            _url_ = discoverUrl + "/start/" + str(_id_)
            _query_ = {"profile":discoveryProfile, "scope":discoveryScope}

        else:
            if _task_ != "delete":
                _query_["feed"] = "json"
                
            if _task_ == "delete":
                _query_["delete"] = "true"
                

            #if _task_ in ["update", "create"]:
                #_query_["depth"] = queryDepth
                #_query_["fetchSize"] = fetchSize
                #_query_["feed"] = "json"

        
            if _task_ in ["query", "mss"]:
                _query_["depth"] = queryDepth
                _query_["fetchSize"] = fetchSize
                #_query_["feed"] = "json"

                
                if _task_ == "mss" and (not regMss_guid == None):
                    _query_["mssGuid"] = regMss_guid
                                
            if not _task_ in ["query", "mss","delete"]:                
                if not (regMss_guid == None or regMss_guid == ""):
                    _query_["mssGuid"] = regMss_guid
                
            if _guid_ == None and _attr_ == None:
                _url_ = restUrl + "/" + _resourceType_

            else:
                #if not _guid_ == None:

                if (not _guid_ == None) and (not _task_ in ["update"]):
                #if not _guid_ == None:
                    _url_ = restUrl + "/ModelObject""/" + str(_guid_)
                   
                    if _task_ in ["query"]:
                        _query_["depth"] = queryDepth
                        _resouceFilter_ = None
                elif (_task_ in ["update"]):
                    _url_ = restUrl + "/" + str(_resourceType_)
                else:
                    if _attr_ == None:
                        _attr_ = "*"
                    _url_ = restUrl + "/MQLQuery"
                    _query_["query"] = "select " + _attr_ + " from " + only + " " + _resourceType_
                    if _resourceFilter_ != None and _resourceFilter_ != "":
                        _query_["query"] = _query_["query"] + " where " + _resourceFilter_
                    if not orderBy == "":
                        _query_["query"] = _query_["query"] + " order by " + orderBy 


            if  _attr_ != "*" and _attr_ != None :
                _query_["cols"] = _attr_     
        
        if str(_query_) == "{}":
            _query_ = None

        ##print "MMMM     _task_:   " + str(_task_)
        ##print "MMMM     _url_:   " + str(_url_)
        ##print "MMMM     _query_: " + str(_query_)
            
        traceit ("<<< " + _name_ , " returned: " + str(_url_) + ", " + str(_query_))

        return(_url_, _query_)
        
    except:
        logit ("Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            
        
        
#
#  Read the http page using get
#  and return attributes in a dictionary
#    
def get_object(_url_=None, _query_=None, _data_=None, _type_=None):
    
    _name_ = "get_object"    
    traceit (">>> entering " + _name_ , " for URL:" + str(_url_) + ", QUERY:" + str(_query_) + ", DATA: " + str(_data_) + ", TYPE:" + str(_type_))
    try:
        
        rc, _res_ = http_process(_url_, _data_, _query_, "GET")

        _attr_ = None            

        if _type_ == "meta":
            _attr_ = _res_
        elif not _res_ == None:    
            _attr_, rc = parse_json_string(_res_)
            if rc > 0:
                raise Exit(4,_name_ + ": invalid jython string while finding attributes")
        
        traceit ("<<< " + _name_ , " returned: " + str(_attr_))
        return(_attr_)
    
    except:
        logit ("Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            





#
#   Get the guid from a rest model object or query 
#
#
#   Get the guid from a rest model object or query 
#
def get_guids(_resourceType_=None, _resourceFilter_=None, getMSS=False):

    _name_ = "get_guids"
    traceit(">>> entering " + _name_ , ": " + str(_resourceType_) + "," + str(_resourceFilter_))
    
    #try:
    if True:
        _obj_ = []
        ###MMM###_url_, _query_ = build_query_url("guid,displayName", None, _resourceType_, _resourceFilter_, "query", selectOnly, resultOrderBy)
        _url_, _query_ = build_query_url("*", None, _resourceType_, _resourceFilter_, "query", selectOnly, resultOrderBy)
        
        
        ###MMM###
        ###print "++==    " + str(_query_)
        ###MMM###

        
        
        rc = 0
        _res_ = []

        rc, _res_ = http_process(_url_, None, _query_, "GET", _resourceType_)

        ###MMM###
        ##print "++==    " + str(_res_)
        ###MMM###

        _guid_ = {}
        
        if rc == 0 and _res_ != "[]":    
            _lst_ = parse_json_list(_res_)
            for a in _lst_:
                _dict_, rc = parse_json_string(a)
                if rc > 0:
                    raise Exit(4,_name_ + ": invalid jython string while finding guids")

                if not  "displayName" in _dict_:
                    _dict_["displayName"] = "<Unknown>"

                _guid_[_dict_["guid"]] = _dict_["_class"] + "," + _dict_["displayName"]         

                ###MMM###
                ##print "++== " + str(_dict_["guid"])
                ###MMM###

                if  resources.find(_dict_["guid"]) == None:
                    
                    if getMSS:
                        res = managementSystem(_dict_["guid"], _dict_["_class"], _dict_["displayName"])
                        _obj_.append(res)
                    else:
                        if resources.count() >= int(fetchSize):
                            break
                        else:
                            res = resource(_dict_["guid"], _dict_["_class"], _dict_["displayName"])
                            _obj_.append(res)
                        ###MMM###
                        ##print "++== " + str(res.displayName)
                        ###MMM###
     
                    
                       
        traceit ("<<< leaving " + _name_)
        
        return _obj_
    
    #except:
    #    logit ("Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            



#
#   Get the guid from a rest model object or query 
#
def get_guids_from_groups(_resourceGroups_, _resourceType_=None, _resourceList_=None):
    
    _name_ = "get_guids_from_groups"
    traceit(">>> entering " + _name_ , ": " + str(_resourceType_) + "," + str(_resourceList_))
        
    try:
        _groups_ = string.split(_resourceGroups_, ",")

        # find the groups
        for _g_ in _groups_:
            _resourceGroupType_ = ""
            _resourceGroupName_ = ""
            
            if string.find(_g_,":") == -1:
                _resourceGroupName_ = _g_
            else:    
                _resourceGroupType_, _resourceGroupName_ = string.split(_g_, ":", 1)                
            
            if _resourceGroupType_ == "" and not _resourceType_ == None:
                _resourceGroupType_ = _resourceType_
                    
            _resourceGroupType_ = string.strip(_resourceGroupType_,'"') 
            _resourceGroupType_ = string.strip(_resourceGroupType_,"'")     
            _resourceGroupName_ = string.strip(_resourceGroupName_,'"') 
            _resourceGroupName_ = string.strip(_resourceGroupName_,"'") 

        
            _filter_ = "displayName equals '" + _resourceGroupName_ + "'"
            _url_, _query_ = build_query_url("guid,displayName", None, _resourceGroupType_, _filter_, "query", "only")
            
            ###MMM###
            ##print "++= " + str(_query_)
            ###MMM###
            
            rc = 0
            _res_ = []
            rc, _res_ = http_process(_url_, None, _query_, "GET", _resourceGroupType_)

            if rc == 0 and _res_ != "[]":    
                _lst_ = parse_json_list(_res_)
                for a in _lst_:
                    _dict_, rc = parse_json_string(a)
                    if rc > 0:
                        raise Exit(4, _name_ + ": invalid jython string while finding groups")

                    if not  "displayName" in _dict_:
                        _dict_["displayName"] = "<Unknown>"
                    g = group(_dict_["guid"], _dict_["displayName"], _dict_["_class"])
                        
        
        # find and explode sub-groups
        
        do_it = True
        while do_it:
            i = 0
            num_of_grps = groups.count()
            grps = groups.enum()
            if i == num_of_grps:
                break
            while i < num_of_grps:
                g = grps[i] 
                #for g in groups.enum():
                i = i + 1
                if g.processed == True:
                    do_it = False
                else:
                    do_it = True
                    
                    _mbr_, _mbrType_ = g.get_members()

                    for _m_ in _mbr_:
                    
                        _lst_, rc = parse_json_string(_m_)  
                        
                        if not _mbrType_ == "":
                            if groups.find(_lst_["_class"]) == None:
                                s = group(_lst_["guid"], "temp", _lst_["_class"])
                                g.hasMembers = True
                    g.processed = True
                    
                        

            ##         
            ## filter the results
            ##
            for g in groups.enum():
                if groupResourcesOnly:
                    if not resources.find(g.guid) == None and g.hasMembers:
                        resources.remove(resources.find(g.guid))
                else:
                    if g.hasMembers and  resources.find(g.guid) == None:
                        _attr_ = get_guid_attributes(g.guid, g._class)
                        resource(g.guid, g._class, _attr_["displayName"])
 
                if (not groupGroupsOnly) and (g.hasMembers):

                    _mbr_, _mbrType_  = g.get_members()
                    for _m_ in _mbr_:
                        _dict_, rc = parse_json_string(_m_)
                        if not groupGroupsOnly:
                            if resources.find(_dict_["guid"]) == None:
                                _attr_ = get_guid_attributes(_dict_["guid"], _dict_["_class"])
                                resource(_dict_["guid"], _dict_["_class"], _attr_["displayName"])
                        else:
                            if not resources.find(_dict_["guid"]) == None:
                                resources.remove(resources.find(_dict_["guid"]))
                    
        traceit ("<<< " + _name_ , " returned: " + str(_res_))
        
        return
        
    except:
        logit ("Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            

#
#   Get the guid from a rest model object or query 
#
def get_guids_from_mss(_mss_,_resourceType_=None,_resourceFilter_=None):
    global mss_guid
    _name_ = "get_guids_from_mss"
    traceit(">>> entering " + _name_ , ": " + str(_mss_) + "," + str(_resourceType_) + "," + str(_resourceFilter_))
        
    try:
        
        _res_ = []
        _mssFilter_ = None
        _mssIsString_ = False
        
        if not _mss_ == None:
            
            if len(_mss_) == 32:
                _mssIsString_ = False
                for a in _mss_:
                    if not a in string.hexdigits:
                        _mssIsString_ = True 
            else:
                _mssIsString_ = True
        
            if _mssIsString_:
                _mssFilter_ = "displayName equals '" + _mss_ + "'"
            else:    
                _mssFilter_ = "guid equals '" + _mss_ + "'"           
                   
            _lst_ = get_guids("ManagementSoftwareSystem", _mssFilter_, True)
             
            if not len(_lst_) == 0 :
                mss_guid = _lst_[0].guid
                mss_name = _lst_[0].displayName
                mss_obj = _lst_[0]
            else:
                raise Exit(4, "The management software system you have specified '" + str(_mss_) + "' is not known to the TADDM server.")
                         

            _url_, _query_ = build_query_url("guid,displayName", None, _resourceType_, _resourceFilter_, "mss", selectOnly, resultOrderBy)

            rc = 0
            rc, _res_ = http_process(_url_, None, _query_, "GET", None)
        
            _guid_ = {}
        
            if rc == 0 and _res_ != "[]":    
                _lst_ = parse_json_list(_res_)
                for a in _lst_:
                    _dict_, rc = parse_json_string(a)
                    if rc > 0:
                        raise Exit(4, _name_ + ": invalid jython string while finding guids")

                    if not  "displayName" in _dict_:
                        _dict_["displayName"] = "<Unknown>"

                    _guid_[_dict_["guid"]] = _dict_["_class"] + "," + _dict_["displayName"]
                         
                    if  resources.find(_dict_["guid"]) == None:
                        res = resource(_dict_["guid"], _dict_["_class"], _dict_["displayName"])
                        
        traceit ("<<< " + _name_ , " returned: " + str(_res_))
        
        return
    
    except:
        logit ("Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            

            
            
#
#   Get the guid from a rest model object or query 
#
def get_guids_from_guids(_guidList_=None, _resourceList_=None, getMSS=False):
    
    _name_ = "get_guids_from_guids"
    traceit(">>> entering " + _name_ , ": " + str(_guidList_) + "," + str(_resourceList_))
        
    try:
        
        for _g_ in _guidList_:

            if resources.count() >= int(fetchSize):
                break

            _obj_ = []
            _url_, _query_ = build_query_url("guid,displayName", _g_, None,None, "query", selectOnly, resultOrderBy)
    
            rc = 0
            _res_ = []

            rc, _res_ = http_process(_url_, None, _query_, "GET", None)
        
            _guid_ = {}
        
            if rc == 0 and _res_ != "[]":    
                _lst_ = parse_json_list(_res_)
                for a in _lst_:
                    _dict_, rc = parse_json_string(a)
                    if rc > 0:
                        raise Exit(4, _name_ + ": invalid jython string while finding guids")

                    if not  "displayName" in _dict_:
                        _dict_["displayName"] = "<Unknown>"

                    _guid_[_dict_["guid"]] = _dict_["_class"] + "," + _dict_["displayName"]
                         
                    if  resources.find(_dict_["guid"]) == None:
                    
                        if getMSS:
                            res = managementSystem(_dict_["guid"], _dict_["_class"], _dict_["displayName"])
                        else:
                            res = resource(_dict_["guid"], _dict_["_class"], _dict_["displayName"])
    
                        
                        _obj_.append(res)
                    
                                                    
        traceit ("<<< " + _name_ , " returned: " + str(_res_))
        
        return
    
    except:
        logit ("Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            

            
            
#
#   Get the guid from a rest model object or query 
#
def get_guids_from_list(_resourceType_=None, _resourceList_=None):
    
    _name_ = "get_guids_from_list"
    traceit(">>> entering " + _name_ , ": " + str(_resourceType_) + "," + str(_resourceList_))
        
    try:
        
        parse_resourceAttributes_as_Filter(resourceList)
        _res_ = []        

        for s in signatures.enum():
            _lst_ = get_guids(s._class, s.query)
            
            for r in _lst_:
                if resources.count() >= int(fetchSize):
                    break
                _res_.append(str(s.match(r)))                                
            if resources.count() >= int(fetchSize):
                break
                                                    
        traceit ("<<< " + _name_ , " returned: " + str(_res_))
        
        return
    
    except:
        logit ("Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            


#
#   Get the guid from a rest model object or query 
#
def get_guids_from_types(_resourceType_=None, _resourceFilter_=None):
    
    _name_ = "get_guids_from_types"
    traceit(">>> entering " + _name_ , ": " + str(_resourceType_) + ","  + str(_resourceFilter_))
        
    try:
        
        for t in string.split(resourceType,","):
            
            _lst_ = get_guids(string.strip(t,string.whitespace), _resourceFilter_)
            
            ###MMM###
            ##print "*************" + str(_lst_)
            ##get_related(_lst_)
            ###MMM###
                                                    
        traceit ("<<< " + _name_ )
        
        return
    
    except:
        logit ("Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            

            

#
#   Get the guid from a rest model object or query 
#
def get_guid_attributes(_guid_=None, _resourceType_=None):
    
    _name_ = "get_guid_attributes"
    traceit(">>> entering " + _name_ , ": " + str(_guid_) + ", " + str(_resourceType_))

    try:
        
        _url_, _query_ = build_query_url("*", _guid_, _resourceType_, "guid equals '" + _guid_ + "'", "query", selectOnly, resultOrderBy)
               
        _attr_ = get_object(_url_, _query_) 

        traceit ("<<< " + _name_ , " returned: " + str(_attr_))
        return(_attr_)
    
    except:
        logit ("Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            

#
#
#
def get_related(resourceList=None):

    _name_ = "get_related"
    traceit(">>> entering " + _name_ )
        
    try:
        # find and explode resources
        
        do_it = True
        while do_it:
            i = 0
            num_of_res = resources.count()
            ress = resources.enum()
            print "************* " + num_of_res
            if i == num_of_res:
                break
            
            while i < num_of_res:
                r = ress[i] 
                #for r in resources.enum():
                i = i + 1
                if r.processed == True:
                    do_it = False
                else:
                    do_it = True
                    
                    _cld_, _cldType_ = r.get_children()

                    for _c_ in _cld_:
                    
                        _lst_, rc = parse_json_string(_c_)  
                        
                        if not _cldType_ == "":
                            if resources.find(_lst_["_class"]) == None:
                                r = resources(_lst_["guid"], "temp", _lst_["_class"])
                                r.hasChildren = True
                    r.processed = True
                    
                        

                                                    
        traceit ("<<< " + _name_ )
        
        return
    
    except:
        logit ("Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            




#
#   Get the guid from a rest model object or query 
#
def get_class_metadata(_resourceType_=None):
    _name_ = "get_class_metadata"
    traceit(">>> entering " + _name_ , ":  " + _resourceType_)
    try:
        
        _url_, _query_ = build_query_url(None, None, _resourceType_, None, "meta")               
        _data_ = get_object(_url_, _query_, None, "meta")         
        
        if _data_[0] == "[":
            _data_ = string.strip(_data_, "[")
        
        _data_ = _data_ + ","
            
        if _data_[len(_data_) - 1] == "]":
            _data_ = string.rstrip(_data_, "]")

        _lst_ = string.split(_data_, "{") 
        
        
        _attr_ = []
        _meta_ = {}
        _save_ = ""
        i = 0
        
        for a in _lst_:
            if len(a) > 0:
                i = i + 1
                a = _save_ + "{" + a
                if a[len(a) - 1] == ",":
                    a = string.rstrip(a, ",")                            
                    _save_ = ""
                    
                    _dict_, rc = parse_json_string("[" + a + "]")

                    if rc > 0:
                        raise Exit(4, _name_ + ": invalid jython string while finding class metadata")
                    
                    _attrname_ = _dict_["name"]
                    _attr_.append(_attrname_)
                    _meta_[_attrname_] = _dict_
                else:
                    _save_ = _save_ + str(a)
        
        traceit ("<<< " + _name_ , " returned: " + str(_meta_))
        return(_attr_, _meta_)
    
    except:
        logit ("Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))            





#
#
#
def resource_update(_guid_, _resourceType_, _data_):
    
    _name_ = "resource_update"
    traceit (">>> entering " + _name_)
    
    if debug: 
        print "@@@@@@@@@@@  Data: " + str(_data_)    
    
    try:
        
        _url_, _query_ = build_query_url(None, _guid_, _resourceType_, None, "update")            
        
        rc, _res_ = http_process(_url_, _data_, _query_, "PUT", _resourceType_)
        return rc, _res_
    
        traceit("<<< leaving " + _name_)
    except Exit, exit_ex:
        exit_ex.printIt()
        exit_ex.leave()

        return
    
    
            
    except:
        raise Exit(4, "Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))
        

#
#
#
def resource_create(_resourceType_, _data_,prompt=True):
    global force  
    _name_ = "resource_create"
    traceit (">>> entering " + _name_ , " ResourceType: " + _resourceType_ + ",  Attributes: " + str(_data_))

    try:
        rc = 0
        _res_ = []
        if not force:
            if prompt:
                doit = ""    
                while not doit == "y":
                    answer = raw_input("\nAre you sure that you wish to create a new " + _resourceType_ + " object from " + str(_data_) + " ? (y(es)/n(o)/a(ll)/N(one)) ")
                    if str(answer).lower() == "a":
                        doit = "y" 
                        force = True
                        answer = "y"
                    if str(answer) == "N":
                        raise Exit (4, "The " + action + " operation of all remaining resources has been cancelled.")                    
                    if not str(answer) == "":
                        doit = string.lower(answer[0])
                    if doit == "n":
                        return 4, None
        
        
        _url_, _query_ = build_query_url(None, None, _resourceType_, None, "create")            

        rc, _res_ = http_process(_url_, _data_, _query_, "PUT", _resourceType_)
        #logit( str(type(rc)) + "   " +  str(rc))
        
        if not rc == 0:
            logit(str(rc))
            logit("A problem was encountered while creating a new " + _resourceType_ + " from " + str(_data_) + ".")
            return rc, _res_
        else:
            _res_ = string.strip(_res_)
            traceit("<<< leaving " + _name_)
            return rc, _res_

    except Exit, exit_ex:
        exit_ex.printIt()
        exit_ex.leave()
        
    except:
        raise Exit(4, _name_ + ": Unexpected Error:   " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))
        



def show_local_time(epoch):
    return time.strftime('%Y-%m-%d %H:%M %Z', time.localtime(float(epoch)/1000))

#
#
def resource_delete(resource):
    global force 
    _name_ = "resource_delete"
    traceit (">>> entering " + _name_ + " resource: " + str(resource))

    try:
                
        r = resource

        _url_, _query_ = build_query_url(None, r.guid, r.className, None, "delete")            
        
        rc, _res_ = http_process(_url_, None, _query_, "DELETE", r.className)

        print "\tDeleted " + r.className + " object " + r.displayName + "(" + r.guid + ")"
        
        traceit("<<< leaving " + _name_)
        return rc    

    except:
        raise Exit(4, "Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1]))
        

    


def list_attributes(_report_, _resource_, guidOnly=False):
    _name_ = "list_attributes"
    traceit (">>> entering " + _name_)

    w = _report_
    r = _resource_

    try:    
        _lstattr_ = None
        if not resourceAttributes == None:
            _lstattr_, rc = parse_json_string(resourceAttributes)
            if rc > 0:
                raise Exit(4, _name_ + ": invalid jython string while listing resources")

        _vals_ = {}
        _typ_ = {}
        _namLen_ = 0
        _typLen_ = 0
        _valLen_ = 0 
        _ressName_ = r.name
        _ressClass_ = r.className

        for a in r.attributes:            
            
            if not _lstattr_ == None and a._instanceName_  not in _lstattr_:
                continue
            
            _val_ = ""
            if  r.values.has_key(a.name): 
                _val_ = str(r.values[a.name])
            if string.find(string.lower(a.type), "string") >= 0:
                _val_ = '"' + str(_val_) + '"'  
            if not action == "export":
                if string.find(string.lower(a.name), "time") >= 0 and string.lower(a.type) == "long" and _val_ != "":
                    _val_ = show_local_time(_val_)                # _val_ = time.strftime('%Y-%m-%d %H:%M', time.gmtime(float(_val_)))

            if not (compactPrint and _val_ in ["", '""', None]):
                _vals_[a.name] = _val_
                _typ_[a.name] = a.type
                if shortFormat == True and string.find(a.type, ".") > 0:
                    _typ_[a.name] = string.rsplit(a.type, ".", 1)[1]
        
        if string.lower(action) == "attr":    
            w.add_header_format(["label"], False)
            w.add_header({"label":"displayName\t:  " + string.strip(r.name, '"')})
#            w.add_header({"label":"type\t\t:  " + r.type})
            w.add_header({"label":"_class\t\t:  " + r.className})
            w.add_header({"label":"guid\t\t:  " + r.guid})
            w.add_spacer("=")
            
            w.add_line_format(["name", "type", "value"])
            w.add_line({"name":"name", "value":"value", "type":"type"})
            w.add_spacer("-")
        else:    
            w.add_line_format(["json"])

        keys = _vals_.keys()
        keys.sort()

        _cnt_ = 0
        #_json_ = {"guid":r.guid, "type":r.className, "name":r.name}
        _json_ = {}
        _guid_ = str(r.guid) 
        _line_ = {}
        

        
        for _k_ in keys:
            if string.lower(action) == "attr":
                _line_ = {}
                _line_["name"] = _k_
                _line_["value"] = _vals_[_k_]
                _line_["type"] = _typ_[_k_]
                w.add_line(_line_)
            if string.lower(action) == "export":

                if _k_ not in _json_.keys():
                    if (not noIDs) or (noIDs and _k_ not in exportExcludeForImport):
                        _json_[_k_] = string.strip(_vals_[_k_],'"')
            _cnt_ = _cnt_ + 1

        if string.lower(action) == "export":
            if guidOnly:
                w.add_line({"json":"{"+_guid_+"}"})
            else: 
                _line_["json"] = encode_data(_json_)
                
                _line_["json"] = string.strip(_line_["json"],"[")
                _line_["json"] = string.strip(_line_["json"],"]")
                _line_["json"] = "[" + _ressClass_ + ":" + _line_["json"] + "]"
                w.add_line(_line_)
            
        else:    
            if compactPrint:
                w.add_summary("\nShowing " + str(_cnt_) + " of " + str(len(r.attributes)) + " atributes.")     
                
        traceit ("<<< leaving " + _name_)
        return
        
    except:
        print "Unexpected Error in " + _name_ + ": " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1])

        pass
    traceit("<<< leaving " + _name_)
        
    return()


#########################
#########################
#########################
def list_modifications():
    rc = 0
    _name_ = "list_modifications"
    traceit (">>> entering " + _name_)

    resultOrderBy = None
    
    w = report()
    w.add_header_format(["action","guid", "class", "displayName", "attribute", "old-value", "new-value", "type"])
    w.add_header({"action":"action","guid":"guid", "class":"_class", "displayName":"displayName", "attribute":"attribute", "old-value":"old value", "new-value":"new value", "type":"type"})
    w.add_spacer("-")
    w.add_line_format(["action","guid", "class", "displayName", "attribute", "old-value", "new-value", "type"])
    
    _curGui_ = None
    
    for _mod_ in modifications.enum():
        
        if _mod_.ignore == True:
            continue
        
        _guiVal_ = ""
        _cls_ = ""
        _dsp_ = ""
        _act_ = ""

        #if _mod_.task == "create":
        #    _gui_ = ""
        #    sign = _mod_.resource
        #    _cls_ = sign._class
        #    _dsp_ = ""
        #    
        #else:
        if True:    
            resource = _mod_.resource
            attribute = _mod_.attribute
            _gui_ = resource.guid
                
            if not _gui_ == _curGui_:
                _curGui_ = _gui_
                _act_ = _mod_.task
                u = update(_gui_, resource,_mod_) 
                _guiVal_ = _gui_
                _cls_ = resource.className
                _dsp_ = resource.displayName
                _act_ = _mod_.task
        
        _attrName_ = attribute.name
        _type_ = str(attribute.type)
        _newVal_ = _mod_.new_value
        
        
        if shortFormat == True and string.find(_type_, ".") > 0:
            _type_ = string.rsplit(_type_, ".", 1)[1]

        _oldVal_ = ""
        if resource.values.has_key(_attrName_):
            _oldVal_ = resource.get_values(_attrName_)
            
        if string.find(string.lower(_type_), "string"):
            _oldVal_ = '"' + _oldVal_ + '"' 
            _newVal_ = '"' + _newVal_ + '"' 

        if not _oldVal_ == _newVal_ :
            w.add_line({"action":_act_,"guid":_guiVal_, "class":_cls_, "displayName":_dsp_, "attribute":_attrName_, "old-value":_oldVal_, "new-value":_newVal_, "type":_type_})
            
        u.add(_attrName_, _newVal_)  
    
    if not force:    
        print >> outFileHandle, "\nYou are about to perform the following " + action + "s."
        w.printIt()

    traceit("<<< leaving " + _name_)
        
    return(rc)





def parse_newattributes(_attr_, _meta_):

    _name_ = "parse_newattributes"
    traceit (">>> entering " + _name_ , "  newAttributes: " + str(_attr_) + ",  meta: " + str(_meta_))

    _new_, rc = parse_json_string(_attr_)
    if rc > 0:
        raise Exit(4, _name_ + ": invalid jython string while parsing attributes")
    
    _known_ = {}
    _unknown_ = []        
    _a_ = _meta_.keys()
    
    for a in _new_.keys():
        if a in _a_:
            _m_ = _meta_[a]
            _known_[a] = _new_[a]
            #print "KNOWN:\t" + a + " " + str(_known_[a])
        else:
            #print "UNKNOWN:\t'" + a + "' is not valid for " 
            _unknown_.append(a)

    traceit("<<< leaving " + _name_ , " returning KNOWN:" + str(_known_) + ",  UNKNOWN:" + str(_unknown_))

    return(_known_, _unknown_)

'''
#
#
#
def parse_newattributes(_attr_, _meta_):

    _name_ = "parse_newattributes"
    traceit (">>> entering " + _name_ , "  newAttributes: " + str(_attr_) + ",  meta: " + str(_meta_))

    _new_ = parse_json_string(_attr_)    
    _known_ = {}
    _unknown_ = []        
    _a_ = _meta_.keys()
    
    for a in _new_.keys():
        if a in _a_:
            _m_ = _meta_[a]
            _known_[a] = _new_[a]
            #print "KNOWN:\t" + a + " " + str(_known_[a])
        else:
            #print "UNKNOWN:\t'" + a + "' is not valid for " 
            _unknown_.append(a)

    traceit("<<< leaving " + _name_ , " returning KNOWN:" + str(_known_) + ",  UNKNOWN:" + str(_unknown_))

    return(_known_, _unknown_)
'''
#
#
#
def parse_resourceAttributes_as_Filter(_attr_=None):
 
    _name_ = "parse_resourceAttributes_as_Filter"
    traceit (">>> entering " + _name_ , "  attributes: " + str(_attr_))

    #_l_ = _attr_
    #_l_ = string.strip(_l_, "[")
    #_l_ = string.strip(_l_, "]")
    #_typ_, _l_ = string.split(_l_,":",1)
        
    #_l_ = string.strip(_l_, "{")
    #_l_ = string.strip(_l_, "}")
    #_lst_ = _typ_ + ":{" + _l_ + "}"
        
    #_lst_ = parse_json_list(_lst_)    


    _lst_ = parse_json_list(_attr_)
    _qry_ = ""
    
    
    for _l_ in _lst_:
        _l_ = string.strip(_l_, "[")
        _l_ = string.strip(_l_, "]")
        _l_ = string.strip(_l_, "{")
        _l_ = string.strip(_l_, "}")

        _resType_, listAttributes = string.split(_l_,":",1)    
        listAttributes = string.strip(listAttributes, "{")
        _l_ = string.strip(listAttributes, "}")

        _qry_ = ""
        _dict_, rc = parse_json_string(_l_)
        if rc > 0:
            raise Exit(4, _name_ + ": invalid jython string while parsing filter attributes")
    
            
        #_resType_ = resourceType
        for _key_ in _dict_.keys():
            if _key_ == "_class":
                _resType_ = _dict_[_key_]
            else:
                if not _qry_ == "":
                    _qry_ = _qry_ + " and "
                _qry_ = _qry_ + _key_ + " equals " + '"' + _dict_[_key_] + '"'
        
        _s_ = signature(_l_, _qry_, _resType_)
    

    traceit("<<< leaving " + _name_ , " returning :" + str(_qry_))
        
    return


################
###############
def openFiles(outFile, logFile, errFile):
    
    global outFileHandle, logFileHandle, errFileHandle
    
    _name_ = "openFiles"
    
    if not outFile == None: 
        outFileHandle = open(outFile, "w")
    else:
        outFileHandle = sys.stdout
        
    if not logFile == None: 
        logFileHandle = open(logFile, "w")
    else:
        logFileHandle = sys.stdout
             
    if not errFile == None: 
        errFileHandle = open(errFile, "w")
    else:
        errFileHandle = sys.stderr
    
    traceit (">>> entering " + _name_)
        
    traceit("<<< leaving " + _name_)
    return

################
###############
def closeFiles():
    
    _name_ = "closeFiles"
    traceit (">>> entering " + _name_)
        
    traceit("<<< leaving " + _name_)
    try:
        if not outFileHandle == None:
            if not outFileHandle.name == "<stdout>":
                outFileHandle.flush()
                outFileHandle.close()
        if not logFileHandle == None:
            if not logFileHandle.name == "<stdout>":
                logFileHandle.flush()
                logFileHandle.close()
        if not errFileHandle == None:
            if not errFileHandle.name == "<stderr>":
                errFileHandle.flush()
                errFileHandle.close()
        #print "deleting:  " +  str(pidFileHandle.name)
        os.unlink(str(pidFileHandle.name))
        os.remove(str(pidFileHandle.name))
    except:
        pass

    return


def parse_resource_attributes(_resAttr_):

    _name_ = "parse_resource_attributes"
    traceit (">>> entering " + _name_)
    
    _lne_ = ""
    _lst_ = string.split(_resAttr_, ",")
    attributeIgnore = []
    
    if _lst_[0] == '[':
        _lne_ = "["
        _lst_ = _lst_[1:]
    
    if _lst_[0] == '{':
        _lne_ = "{"
        _lst_ = _lst_[1:]
    
        
    for a in _lst_:
        
        #if string.find(a,":") > 0:
        _val_ = None
          
        if string.find(a, ":") > -1:
            _att_, _val_ = string.split(a, ":", 1)
        else:
            _att_ = a

        _ttt_ = string.strip(_att_, "'")
        _ttt_ = string.strip(_ttt_, '"')
        _ttt_ = string.strip(_ttt_, "'")
        _ttt_ = string.strip(_ttt_, string.whitespace)
        
        if _val_ in ["", None]:
            _att_ = '"' + _ttt_ + '"'
            _val_ = '""'
            attributeIgnore.append(string.strip(_ttt_, string.whitespace))
        else:
            _rrr_ = string.strip(_val_, "'")
            _rrr_ = string.strip(_rrr_, '"')
            _rrr_ = string.strip(_rrr_, "'")
            _att_ = '"' + _ttt_ + '"' 
            _val_ = '"' + _rrr_ + '"'
            
        if not _lne_ == "":
            _lne_ = _lne_ + ","
        _lne_ = _lne_ + str(_att_) + ":" + _val_
    
    traceit("<<< leaving " + _name_)    
    return(_lne_, attributeIgnore)
    
#        
#          
#
def main(argv=None):
    if argv is None:
        argv = sys.argv
    #opts = None

    global debug, quiet, trace, force 
    global tindent, lindent, progname, prog, hostname
    global taddmServerPort, taddmServerHost, taddmServerUser, taddmServerPassword
    global restUrl, discoverUrl, taddmServerUrl
    global resourceAttributes, resourceType, resourceClass, resourceList 
    global httpOpener, passdict
    global taddmRealm
    global tracer
    global queryDepth, fetchSize
    global discoveryProfile, discoveryScope
    global action
    global outFileHandle, logFileHandle, errFileHandle, pidFileHandle
    global basicAuth, shortFormat, compactPrint
    global resources, cdmclasses, attributes, signatures, modifications, updates, managementSystems, groups
    global selectOnly, resultOrderBy
    global groupTypes, groupResourcesOnly,groupGroupsOnly,groupMembers
    global noIDs, exportExcludeForImport
    global regMss_guid,mss,mss_guid
    global placeHolder, placeHolderSet
    
    
    if True:
        attributes = structure() 
        cdmclasses = structure()
        resources = structure()
        signatures = structure()
        managementSystems = structure()
        groups = structure()



    
        basicAuth = True       
        taddmServerHost = "localhost"
        taddmServerPort = "9430"
        taddmServerUser = None
        taddmServerPassword = None
        resourceFilter = None
        quiet = False
        debug = False
        trace = False
        force = False
        action = None
        tindent = 0
        lindent = 0
        resourceType = None
        queryDepth = 1
        fetchSize = 1
        regMss = None
        discoveryProfile = "Level 1 Discovery"
        restUrl = "/rest/model"
        discoverUrl = "/rest/discover"
        compactPrint = False
        shortFormat = False
        resourceAttributes = None
        resourceList = None
        resourceGuids = None
        resourceGroups = None
        resourceFilter = None
        inFile = None
        outFile = None
        logFile = None
        errFile = None
        logFileHandle = sys.stdout
        outFileHandle = sys.stdout
        errFileHandle = sys.stderr
        attributesIgnore = []
        selectOnly = False
        resultOrderBy = None
        groupTypes = ["components", "groups","members","servers"]
        guidOnly = False
        groupResourcesOnly = False
        groupGroupsOnly = False
        groupMembers = "all"
        exportExcludeForImport = ["lastModifiedTime","lastModifiedBy","guid","type"]        
        noIDs = False
        mss=None
        mss_guid=None
        combinedList = False
        showBanner = False
        showVersion = False
        version = "1.0.2"
        optMsg = None
        placeHolder = False
        placeHolderSet = False
 
    try:
       
        shortOpts = "a:A:bBcC:dDe:fF:gG:hH:i:Ikl:L:m:M:nNo:O:p:P:qQ:R:sS:tT:u:vW:"
        longOpts = ["action=","attributes=","basicAuth","banner","compact","groups=","debug","distinct","err=","force","filter=","guidOnly","guids=","help","host=","input=","info","combined","log=","list=","members=","mss=","noguids","placeHolder","output=","orderby=","password=","port=","quiet","depth=","registermss=","shortformat","fetchsize=","trace","type=","user=","version","profile="]
        
        opts = {}
        args = {}

        new_argv = []
        new_argv.append(argv[0])

        hostname = socket.getfqdn()

        dirname, progname = os.path.split(argv[0])    
        prog,ext = string.rsplit(progname, ".",1)
        pidFileHandle = open(prog+".pid","w")
        print >> pidFileHandle,  str(os.getpid())        
        pidFileHandle.flush()
        pidFileHandle.close()
        inFile = prog + ".ini"
        inFileOpt = False
        
        try:            
            
            if len(argv) == 1:
                raise Exit(8,"No arguments provided")

            
            opts, args = getopt.getopt(argv[1:], shortOpts, longOpts)
        except GetoptError, err:
            optMsg = err.msg
            #print err.msg
            if len(args) > 0: 
                raise Exit(8,"The following arguments are not valid:" + str(args))
        
        try:   
            lines = None                     
            for o, a in opts:

                if o in ("-h", "--help"):
                    raise Usage("help")
                elif o in ("-I", "--info"):
                    raise Usage("info")
                elif o in ("-i", "--input"):
                    inFileOpt = True
                    inFile = a
                    
            if inFile != None:
                if os.path.exists(inFile):
                    fileName = inFile
                else:
                    fileName = os.path.normpath(dirname) + os.sep + inFile

                if os.path.exists(fileName):
                    f = open(fileName, "r")
                    lines = f.readlines()
                    f.close   
                else:
                    if inFileOpt == True:
                        raise Exit(8, "Error accessing input file '" + str(fileName) + "'")

            # read the arguments from the file to the argv list
            # and ensure that command line arguments are not replaced               
            if not lines == None:
                for i in lines:
                    i = string.strip(i, string.whitespace)
                    if not (i == "" or i[0] == "#"):
                        if string.find(i," ") == -1:
                            prm = None
                            arg = i
                        else:                        
                            arg, prm = string.split(i," ",1)
                        if not arg in str(opts): 
                            new_argv.append(arg)
                            if not prm == None:
                                new_argv.append(prm)
             
            for o,a in opts:
                new_argv.append(o)
                if not a == "" or o in ["-R","--registermss"]:
                    new_argv.append(a)
             
                        
        except IOError, err_ex:
                raise Exit(16, "Unexpected problems accessing input file '")



        try:
            opts, args = getopt.getopt(new_argv[1:], shortOpts, longOpts)
        except getopt.error, msg:
            optMsg = msg
            #print str(msg)
            raise Usage(msg)

        for o, a in opts:

            o = string.strip(o, string.whitespace)
            
            if o in ("-a", "--action"):
                action = string.strip(a)
                action = string.lower(action)
                if not action in ["create", "delete", "list", "attr", "export", "update", "modify", "discover"]:
                    #logit("Invalid action '" + action + "'")
                    raise Exit(4,"Invalid action '" + action + "'")

            elif o in ("-A", "--attributes"):
                resourceAttributes = ""
                try:
                    f = open(a, "r")
                    lines = f.readlines()
                    f.close   
                    for i in lines:
                        i = string.strip(i, string.whitespace)
                        if not (i == "" or i[0] == "#"):
                            i = string.strip(i, "[")
                            i = string.strip(i, "]")
                            if not resourceAttributes == "":
                                resourceAttributes = string.strip(resourceAttributes, ",") + ","
                            resourceAttributes = resourceAttributes + string.strip(i, string.whitespace)
                    resourceAttributes = string.replace(string.strip(resourceAttributes), "'", '"')                                        
                except:    
                    resourceAttributes = string.replace(string.strip(a), "'", '"')
                finally:
                    resourceAttributes, attributesIgnore = parse_resource_attributes(resourceAttributes) 
            elif o in ("-b", "--basicAuth"):
                basicAuth = False
            elif o in ("-B", "--banner"):
                showBanner = True
            elif o in ("-c", "--compact"):
                compactPrint = True
            elif o in ("-C", "--groups"):
                resourceGroups = ""
                try:
                    f = open(a, "r")
                    lines = f.readlines()
                    f.close   
                    for i in lines:
                        i = string.strip(i, string.whitespace)
                        if not (i == "" or i[0] == "#"):
                            i = string.strip(i, "[")
                            i = string.strip(i, "]")
                            if not resourceGroups == "":
                                resourceGroups = string.strip(resourceGroups, ",") + ","
                            resourceGroups = resourceGroups + string.strip(i, string.whitespace)
                    resourceGroups = string.replace(string.strip(resourceGroups), "'", '"')                                        
                except:    
                    resourceGroups = string.replace(string.strip(a), "'", '"')
            elif o in ("-d", "--debug"):
                debug = True
            elif o in ("-D", "--distinct"):
                selectOnly = True
            elif o in ("-e", "--err"):
                errFile = a
            elif o in ("-f", "--force"):
                force = True
            elif o in ("-F", "--filter"):
                resourceFilter = ""
                try: # if the name references  valis file, read it
                    f = open(a, "r")
                    lines = f.readlines()
                    f.close   
                    for i in lines:
                        if not (i == "" or i[0] == "#"):
                            resourceFilter = resourceFilter + string.strip(i, string.whitespace)
                    resourceFilter = string.replace(string.strip(resourceFilter), "'", '"')                    
                except:  # otherwise use the parameter as the filter  
                    resourceFilter = string.replace(string.strip(a), "'", '"')
            elif o in ("-g", "--guidOnly"):
                guidOnly = True
            elif o in ("-G", "--guids"):
                resourceGuids = []
                try:
                    f = open(a, "r")
                    lines = f.readlines()
                    f.close   
                    for i in lines:
                        i = string.strip(i, string.whitespace)
                        if not (i == "" or i[0] == "#"):
                            i = string.strip(i, "[")
                            i = string.strip(i, "]")
                            i = string.strip(i, "{")
                            i = string.strip(i, "}")
                            resourceGuids.append(i)
                except:    
                    i = string.strip(a, "[")
                    i = string.strip(i, "]")
                    i = string.strip(i, "{")
                    i = string.strip(i, "}")
                    for b in string.split(i,","):
                        resourceGuids.append(b)
            elif o in ("-h", "--help"):
                raise Usage("help")
            elif o in ("-H", "--host"):
                taddmServerHost = string.strip(a)
                taddmServerIp = socket.gethostbyname(taddmServerHost)
                taddmServerHost, a, b = socket.gethostbyaddr(taddmServerIp)
            elif o in ("-i", "--input"):
                pass
            elif o in ("-I", "--info"):
                raise Usage("info")
            elif o in ("-k", "--combined"):
                combinedList = True            
            elif o in ("-l", "--log"):
                logFile = a
            elif o in ("-L", "--list"):
                resourceList = ""
                try:
                    f = open(a, "r")
                    lines = f.readlines()
                    f.close   
                    for i in lines:
                        i = string.strip(i, string.whitespace)
                        if not (i == "" or i[0] == "#"):
                            i = string.strip(i, "[")
                            i = string.strip(i, "]")
                            if not resourceList == "":
                                resourceList = string.strip(resourceList, ",") + ","
                            resourceList = resourceList + string.strip(i, string.whitespace)
                    resourceList = string.replace(string.strip(resourceList), "'", '"')                    
                except:    
                    resourceList = string.replace(string.strip(a), "'", '"')
            elif o in ("-m", "--members"):
                groupMembers = a
                if string.lower(a) == "groups":
                    groupResourcesOnly = False
                    groupGroupsOnly = True
                elif string.lower(a) == "resources":
                    groupResourcesOnly = True
                    groupGroupsOnly = False
            elif o in ("-M", "--mss"):
                mss = string.strip(a)
            elif o in ("-n", "--noguids"):
                noIDs = True
            elif o in ("-N", "--placeHolder"):
                placeHolder = True
            elif o in ("-o", "--output"):
                outFile = a
            elif o in ("-O", "--orderby"):
                resultOrderBy = string.strip(a)
            elif o in ("-p", "--password"):
                taddmServerPassword = string.strip(a)
            elif o in ("-P", "--port"):
                taddmServerPort = string.strip(a)
            elif o in ("-q", "--quiet"):
                quiet = True            
            elif o in ("-Q", "--depth"):
                queryDepth = a
                if int(queryDepth) == 0:
                    queryDepth = "-1" 
            elif o in ("-R", "--registermss"):
                regMss = string.strip(a)
                if string .lower(regMss) == "none": 
                    regMss = "" 
            elif o in ("-s", "--shortformat"):
                shortFormat = True
            elif o in ("-S", "--fetchsize"):
                fetchSize = string.strip(a)
                if int(fetchSize) == 0:
                    fetchSize = str(1000000) 
            elif o in ("-t", "--trace"):
                trace = True
            elif o in ("-T", "--types"):
                resourceType = string.strip(a)
            elif o in ("-u", "--user"):
                taddmServerUser = string.strip(a)                
            elif o in ("-v", "--version"):
                showVersion = True                
            elif o in ("-W", "--profile"):
                discoveryProfile = string.strip(a)
            else:
                raise Exit(4, "You provided an unknown option: " + str(o))

        
        if len(args) > 0 and len(opts) > 0:
            a = string.strip(str(opts[len(opts) - 1]), "(")
            a = string.strip(a, ")")
            x, y = string.split(a, ",", 1)
            a = string.strip(x, "'") + " " + string.strip(y, "'")
            raise Exit(4, "Your input was not parsed correctly. The problem is likely related to the '" + str(args[0]) + "' argument number following '" + a + "'") 


        
        #############################
        #############################
        #  show version
        #############################
        #############################
        if showVersion:
            raise Exit(0, prog + " version " + version) 

        
        
        #############################
        #############################
        #  set defaults
        #############################
        #############################

        taddmServerUrl = "http://" + taddmServerHost + ":" + taddmServerPort
        discoveryScope = taddmServerHost



        #############################
        #############################
        #  initial validation
        #############################
        #############################

        
        if optMsg != None and string.find(optMsg,"-R") > 0:
            raise Exit(4, "You MUST provide a MSS value when using the '-R' or '--registerMss' option. Use 'None' to avoid mss registration.")
        
        #if regMss == None and regMssOpt == True:
        #    raise Exit(4, "You MUST provide a MSS value when using the '-R' or '--registerMss' option. Use 'None' to avoid mss registration.")

        if optMsg != None and string.find(optMsg,"-H") > 0 and taddmServerHost == None:
            raise Exit(4, "You MUST provide a host name of ip address of the TADDM storage server using the '-H' or '--host' arguments.")

        if optMsg != None and string.find(optMsg,"-u") > 0 and taddmServerUser == None:
            raise Exit(4, "You MUST provide a user name using the '-u' or '--user' arguments.")

        elif optMsg != None and string.find(optMsg,"-p") > 0 and taddmServerPassword == None:
            raise Exit(4, "You MUST provide password using the '-p' or '--password' arguments.")

        if optMsg != None:
            raise Exit(8, "ERROR\t Incorrect arguments parsed to " + prog + ":\t" + optMsg)

        #if resourceType == None:
        #    if (action in ["create"]) or (action in ["modify"] and not resourceAttributes == None) or (resourceFilter == None and resourceList == None and resourceGroups == None and resourceGuids == None):
        #        raise Exit(4, "You MUST provide a resource type using the '-T' or '--type' arguments.")


    except Usage, err:
                
        if err.msg == "info":
            show_help()
            show_help_details()   
        elif err.msg == "help":
            ##print >> sys.stderr, err.msg
            show_help()
            #show_help_details()   
        #else:
            #show_help()
            #show_help_details()
        
        closeFiles()            
        return 0

    except Exit, exit_ex:

        exit_ex.printIt()
        exit_ex.leave()    
    


######################################################################
######################################################################
######################################################################
######################################################################


    openFiles(outFile, logFile, errFile)

    try:
        
        if basicAuth == True:
            passdict, taddmRealm = basic_auth()
        else:    
            http_authenticate(taddmServerUrl, taddmServerUser, taddmServerPassword, taddmServerHost, taddmServerPort)
    except:
        raise Exit(4, "Error while authenticating with the TADDM server")
        
        
    #####################################
    #  find the resourceSearchOrder
    #####################################
    if True:
        if combinedList:
            resourceSearchOrder ={}
            
            idx = -1
            idx = string.find(str(argv),"'-C'")
            if idx == -1:
                idx = string.find(str(argv),"--group")   
            if not idx == -1:
                resourceSearchOrder[idx] = "groups"    

            idx = -1
            idx = string.find(str(argv),"'-L'")
            if idx == -1:
                idx = string.find(str(argv),"--list")   
            if not idx == -1:
                resourceSearchOrder[idx] = "lists"    

            idx = -1
            idx = string.find(str(argv),"'-G'")
            if idx == -1:
                idx = string.find(str(argv),"--guid")   
            if not idx == -1:
                resourceSearchOrder[idx] = "guids"    

            idx = -1
            idx = string.find(str(argv),"'-T'")
            if idx == -1:
                idx = string.find(str(argv),"--type")   
            if not idx == -1:
                resourceSearchOrder[idx] = "types"    

            resourceSearchOrderList = ""
            resourceSearchOrderOrder = []
            resourceSearchOrderOrder = resourceSearchOrder.keys()
            resourceSearchOrderOrder.sort()
            for i in resourceSearchOrderOrder:
                if not resourceSearchOrderList == "":
                    resourceSearchOrderList = resourceSearchOrderList + " ,"
                resourceSearchOrderList = resourceSearchOrderList  + str(resourceSearchOrder[i])

        
            


    
        
    try:
        
        if action == None:
            raise Exit(4,"You MUST provide a valid action using the -a or --action arguments")
       
        
        #####################################
        #####################################
        # Get the registerMss
        #####################################
        #####################################    
        
        regMss_guid = None
        _regMssFilter_ = None
        _regMssIsString_ = False
        
        if regMss == "":
            regMss_name = None
            regMss_guid = None
            
        elif regMss == None: 

            _regMssFilter_ = "MSSName equals 'TADDM_Proactive_Update@" + hostname + "' and hostname equals '" + hostname + "' and  productName equals 'TADDM' and subcomponent equals 'Proactive' and subcomponentInstanceName equals '" + progname + "'"
        
        else:
            if len(regMss) == 32:
                _regMssIsString = False
                for a in regMss:
                    if not a in string.hexdigits:
                        _regMssIsString_ = True 
            else:
                _regMssIsString_ = True
        
            if _regMssIsString_:
                _regMssFilter_ = "displayName equals '" + regMss + "'"
            else:    
                _regMssFilter_ = "guid equals '" + regMss + "'"           
       
        if not regMss == "":
            
            _lst_ = get_guids("ManagementSoftwareSystem", _regMssFilter_, True)
             
            if not managementSystems.count() == 0 :
                regMss_guid = _lst_[0].guid
                regMss_name = _lst_[0].displayName
                regMss_obj = _lst_[0]
            else:
                if regMss == None:            
                    rc, regMssObj = regMss_create()
                    if rc == 0:
                        regMss = regMssObj.guid
                        regMss_guid = regMssObj.guid
                        regMss_name = regMssObj.displayName
                else:
                    raise Exit(4, "The management software system you have provided '" + str(regMss) + "' is not known to the TADDM server.")
                   

        
        ##########################
        ##########################
        #
        #  show banner
        #
        ##########################
        ##########################
        if showBanner == True:
            print "\nStarting "+ progname + " version " + version + " using the following options: "
            print "-----------------------------------------------------"
            print "  --action (-a)\t\t: " + string.lower(action)
            if not inFile == None:
                print "  --input (-i)\t\t: " + str(inFile)
            if string.lower(action) in ["modify","create","update","delete"]:
                print "      --force (-f)\t: " + str(force)
            print "  TADDM options:"
            print "     --host (-H)\t: " + str(taddmServerHost)
            print "     --port (-P)\t: " + str(taddmServerPort)
            print "     --user (-u)\t: " + str(taddmServerUser)
            print "     --password (-p)\t: " + str("*****")
            print "  Resource options:"
            print "     --combined (-k)\t: " + str(combinedList)
            if combinedList:
                print "     searchOrder\t: " + str(resourceSearchOrderList)
            if not resourceList == None: 
                print "     --list (-L)\t: " + str(resourceList)
            if not resourceGuids == None: 
                print "     --guids (-G)\t: " + str(resourceGuids)
            if not resourceGroups == None: 
                print "     --collections (-C)\t: " + str(resourceGroups)
                print "       --members (-m)\t: " + str(groupMembers)
            if not resourceType == None: 
                print "     --type (-T)\t: " + str(resourceType)
                print "       --distinct (-D)\t: " + str(selectOnly)
            if not mss == None:
                print "       --mss (-M)\t\t: " + str(mss)
            if not resourceFilter == None: 
                print "       --filter (-F)\t: " + str(resourceFilter)
            if not resourceAttributes == None: 
                print "  Attribute options:"
                print "     --attributes (-A)\t: " + str(resourceAttributes)
            print "  Query options:"
            if int(fetchSize) == 1000000:
                print "      --fetchSize (-S)\t: unlimited"
            else:
                print "      --fetchSize (-S) \t: " + str(fetchSize)
            print "      --depth (-Q)\t: " + str(queryDepth)
            print "  Register MSS (-R)\t: " + str(regMss_name)
            print "  Output options:"
            if not resultOrderBy == None:
                print "      --orderby (-O)\t: " + str(resultOrderBy) 
            if not outFile == None:
                print "      --out (-o)\t: " + str(outFileHandle.name)
            if not logFile == None:
                print "      --log (-l)\t: " + str(logFileHandle.name)
            if not errFile == None:
                print "      --err (-e)\t: " + str(errFileHandle.name)
            if compactPrint:
                print "      --compact (-c)\t: " + str(compactPrint)
            if shortFormat:
                print "      --shortformat (-s): " + str(shortFormat)
            if debug:
                print "      --debug (-d): " + str(debug)
            print "\n"


        ############################################
        ############################################
        ###  
        ###   add resultOrderBy to resourceAttributelist if it doesn't exist
        ###
        ############################################
        ############################################        

        if not resultOrderBy == None and action not in ["create", "modify", "update", "delete"]:
            if resourceAttributes == None:
                resourceAttributes = '"' + resultOrderBy + '":""'
            else:
                if string.find(resourceAttributes,'"' + resultOrderBy +'"') == -1:
                    resourceAttributes = resourceAttributes + "," + '"' + resultOrderBy + '":""'

        ############################################
        ############################################
        ###  
        ###   discover
        ###
        ############################################
        ############################################        

        if  string.lower(action) == "discover":

            traceit(">>> " + action)

            _url_, _query_ = build_query_url(None, "discover", None, None, "discover")
            rc, _res_ = http_process(_url_, None, _query_, "GET")

            traceit("<<< " + action)
            return (0)



        
        ##########################
        ##########################
        #
        #  get the data
        #
        ##########################
        ##########################

        if resourceType == None and resourceList == None and resourceGroups == None and resourceGuids == None:
            logit("You MUST provide one or more of following arguments: -C, --groups, -G, --guids, -L, --list, -T, --type.")
            return 0
        
        if not combinedList:
            # get from list
            if not resourceList == None:  
                get_guids_from_list(resourceType, resourceList)
            # get from guids
            elif not resourceGuids == None:  
                get_guids_from_guids(resourceGuids)
            # get from groups
            elif not resourceGroups == None:
                if action not in ["create"]:
                    get_guids_from_groups(resourceGroups, resourceType, resourceFilter)
            # get from types
            elif not resourceType == None:
                if action not in ["create"]:
                    if not mss == None:  
                        get_guids_from_mss(mss,resourceType,resourceFilter)
                    else:    
                        ###if not selectOnly:
                        ###    get_guids(resourceType, resourceFilter)
                        ###else:
                            get_guids_from_types(resourceType, resourceFilter)
        else:
            for a in resourceSearchOrderOrder:

                if not resources.count() < int(fetchSize):
                    break
                
                if resourceSearchOrder[a] == "lists":
                    if not resourceList == None:  
                        get_guids_from_list(resourceType, resourceList)
                    
                if resourceSearchOrder[a] == "guids":
                    if not resourceGuids == None:  
                        get_guids_from_guids(resourceGuids)

                if resourceSearchOrder[a] == "groups":
                    if not resourceGroups == None:
                        if action not in ["create"]:
                            get_guids_from_groups(resourceGroups, resourceType, resourceFilter)

                if resourceSearchOrder[a] == "types":
                    if not resourceType == None:
                        if action not in ["create"]:
                            if not mss == None:  
                                get_guids_from_mss(mss,resourceType,resourceFilter)
                            else:    
                                if selectOnly:
                                    get_guids_from_types(resourceType, resourceFilter)
                                else:
                                    get_guids(resourceType, resourceFilter)


        
        if action == "create" and resourceType != None and resourceAttributes != None:
            parse_resourceAttributes_as_Filter(resourceType + ":{" + resourceAttributes + "}")


        if resources.count() == 0 and action not in ["create", "modify"]:
            #logit("Query, using resource filter '" + str(resourceFilter) + "' yielded no resources to process.")
            raise Exit(0, "Query, using resource filter '" + str(resourceFilter) + "' yielded no resources to process.")
            #return 0
        
        if not string.lower(action) in ["modify", "create"]:
            if len(resources.enum()) == 0:
                #logit ("No resources found for " + str(resourceType) + " where '" + str(resourceFilter) + "'.")    
                raise Exit(0, "No resources found for " + str(resourceType) + " where '" + str(resourceFilter) + "'.")
                #return(0)
            
        #############################
        #############################
        #
        #  basic list
        #
        #############################
        #############################     
            
        if action == string.lower(action) == "list" and resourceAttributes == None:
            
            traceit(">>> " + action)
                

            w = report()
            _cols_ = ["guid", "_class", "displayName"]
            _hdr_ = {"guid":"guid", "_class":"_class", "displayName":"displayName"}
            w.add_header_format(_cols_, True)
            w.add_header(_hdr_)    
            w.add_spacer("=")
            
            w.add_line_format(_cols_)
            for r in resources.enum():
                _lne_ = {"guid":r.guid, "_class":r.className, "displayName":r.displayName}
                w.add_line(_lne_)
                
            _num_ = len(resources.enum())    
            if _num_ == 1:
                _msg_ = "\nFound " + str(_num_) + " resource"
            else:
                _msg_ = "\nFound " + str(_num_) + " resources"
            w.add_summary(_msg_)
             
            w.printIt()
                
                
            traceit ("<<< " + action)

            raise Exit(0)


        ###################################
        ###################################
        #
        #  fetch the values
        #
        ###################################
        ###################################
        
        for r in resources.enum():
            r.set_values()


             
        ##########################
        #  print details
        ##########################
        """
        print "=====  " + string.lower(action)
        

        for r in resources.enum():
            print "=====  RES: " + str(r.guid) + str(r.className) + ") has " + str(len(r.attributes)) + " attributes and " + str(len(r.values)) + " values."           
        print ""
        for c in cdmclasses.enum():
            print "=====  CLS: " + c.name + " has " + str(len(c.attributes)) + " attributes and " + str(len(c.usedBy)) + " users"           
        
        """
            
        #############################
        #############################
        #
        #  delete
        #
        #############################
        #############################     
            
        if string.lower(action) == "delete":
            
            if not force: 
                logit("About to delete the following " + str(resources.count()) + " objects.")

                for r in resources.enum():
                    print "  " + r.className + "  '" + str(r.displayName) + "'"
           
            for r in resources.enum():

                if force:
                    r.delete()
                else: 
                    doit = ""
                    while not doit == "y":
                        answer = raw_input("\nAre you sure that you wish to " + action + " '" + r.displayName + "' (" + r.guid + ") ?  (y(es)/n(o)/a(ll)/N(one)) ")
                        if str(answer).lower() == "a":
                            doit = "y" 
                            force = True
                            answer = "y"
                        if str(answer) == "N":
                            raise Exit(0, "The " + action + " operation of all remaining resources has been cancelled.")
                        if not str(answer) == "":
                            doit = string.lower(answer[0])
                        if doit == "n":
                            break
                        if doit == "y":
                            r.delete()    
                
            raise Exit(0)

        #############################
        #############################
        #
        #  create
        #
        #############################
        #############################     
                    
        if action == string.lower(action) == "create":
               
            traceit(">>> " + action)
            
            if  signatures.count() == 0:
                msg = "You did not provide any resources to create using the '-L' or '--list' arguments."
                logit(msg)
                raise Exit(4, msg) 


            for s in signatures.enum():

                if s.matched:
                    r = s.matchedTo[0]
                    logit ("The " + r.className + " object you try to create a already exist as " + r.displayName + " (" + r.guid + ").")
                    s.processed = True

            something_to_do = False
            for s in signatures.enum():
                if not s.matched:
                    something_to_do = True
                    break
            
            if something_to_do:
                if not force:
                    print "you are anbout to create the following objects:"

                _resType_ = resourceType
                for s in signatures.enum():
                    if not s.matched and not s.processed:
                        _str_, rc = parse_json_string(str(s.json) + ',_class:"' + str(s._class) + '"')
                        
                        if rc > 0:
                            raise Exit(4, action + ": invalid jython string while parsing attributes for creation")

                        if _str_.has_key("_class"):
                            _resType_ = _str_["_class"]
                                        
                        if not force:
                            print "\t" +  _resType_ + " object from " + str(_str_)
                    
                for s in signatures.enum():
                    if not s.matched and not s.processed:
                        _str_, rc = parse_json_string(str(s.json) + ',_class:"' + str(s._class) + '"')
                        if rc > 0:
                            raise Exit(4, action + ": invalid jython string while parsing attributes for creation")

                        if _str_.has_key("_class"):
                            _resType_ = _str_["_class"]


                        ###  SET ISPLACEHOLDER Attribute
                        placeHolderSet = False
                        keyList = _str_.keys()
                        for _key_ in keyList:
                            #print "+++++++   _key_: " + _key_
                            if _key_ == "isPlaceholder":
                                placeHolderSet = True;
                        ## add placeholder and ManagedSystemName       
                        if placeHolder and not placeHolderSet:
                            _str_["isPlaceholder"] = "true"     





                        rc, _guid_ = resource_create(_resType_, _str_, True)
                    
                        if _guid_ == None:
                            if rc != 4:
                                logit("could not create resource from signature :" + str(_str_))    
                            continue
                        else:
                            _displayName_ = ""
                            if _str_.has_key("displayName"):
                                _displayName_ = _str_["displayName"]
                            elif _str_.has_key("name"):
                                _displayName_ = _str_["name"]
                            elif _str_.has_key("signature"):
                                _displayName_ = _str_["signature"]
        
                            r = resource(_guid_, _resType_, _displayName_)

                            logit("\tCreated new " + _resType_ + " object '" + _displayName_ + "' as " + r.guid)
                        s.processed = True

            
            
            traceit("<<< " + action)
            raise Exit(0)
        
                     

        #############################
        #############################
        #
        #  customized list
        #
        #############################
        #############################     
        
        if string.lower(action) == "list" and not resourceAttributes == None:
            
            traceit(">>> custom " + action)
                
            _cols_ = ["guid", "_class", "displayName"]
            _hdr_ = {"guid":"guid", "_class":"_class", "displayName":"displayName"}
           
           
            _lstattr_, rc, _attrSeq_ = parse_json_string(resourceAttributes, True) 
            
            if rc > 0:
                raise Exit(4, action + ": invalid jython string while parsing listing attributes")

            for _a_ in _attrSeq_:
                attribute = attributes.find(string.strip(_a_, '"'))
                if attribute == None:
                    raise Exit(8, "Invalid attribute: '" + _a_ + "'")
                else:
                    if not attribute.name in _cols_:
                        _cols_.append(attribute.name)
                        _hdr_[attribute.name] = attribute.name
                
            w = report()
            w.add_header_format(_cols_, True)
            w.add_header(_hdr_)    
            w.add_spacer("=")
            
            w.add_line_format(_cols_)
            for r in resources.enum():
                _lne_ = {"guid":r.guid, "_class":r.className, "displayName":r.displayName}
                for _a_ in _lstattr_:
                    #####
                    if _lne_.has_key(_a_):
                        continue
                    ####
                    _val_ = ""
                    if r.values.has_key(_a_):
                        _val_ = r.get_values(_a_)
                    a = attributes.find(_a_)
                    if string.find(string.lower(a.name), "time") >= 0 and string.lower(a.type) == "long" and _val_ != "":
                        _val_ = show_local_time(_val_)          
                    if string.find(string.lower(a.type), "string") > 0:
                        _val_ = '"' + _val_ + '"'
                    _lne_[_a_] = _val_
                     
                w.add_line(_lne_)
                
            _num_ = len(resources.enum())    
            if _num_ == 1:
                _msg_ = "\nFound " + str(_num_) + " resource"
            else:
                _msg_ = "\nFound " + str(_num_) + " resources"
            w.add_summary(_msg_)
             
            w.printIt()
                
                
            traceit ("<<< " + action)

            raise Exit(0)

        #############################
        #############################
        #
        #  attributes
        #
        #  export
        #
        #############################
        #############################     
        
        if string.lower(action) in ["attr", "export"]:

            traceit(">>> " + action)

            if (str(outFileHandle.name) == "<stdout>" and not quiet) or (str(outFileHandle.name) != "<stdout>"):
                for r in resources.enum():                 
                    w = report()
                    list_attributes(w, r, guidOnly)
                    w.printIt()
            
            if not quiet:
                if string.lower(action) == "attr":         
                    print "\nFound " + str(resources.count()) + " resources"
                else:
                    print "\nSucessfully exported "+ str(resources.count()) + " resources to '" + str(outFileHandle.name + "'")
            
            traceit("<<< " + action)
                                
            raise Exit(0)
        
        
        #############################
        #############################
        #
        #  modify
        #
        #  update
        #
        #############################
        #############################     
        rc = 0            
        if string.lower(action) in ["modify", "update"]:
            
            if placeHolder:
                pl = "isPlaceholder:'true'"
                if  resourceAttributes == None:
                    resourceAttributes = pl  
                else:
                    resourceAttributes = pl + "," + resourceAttributes
                    
            if  resourceAttributes == None:
                raise Exit(4, "You did not provide any new attribute values using the -A or --attributes argument")
            
            updates = structure()
            modifications = structure()
            _newattr_ = {}
            _dict_ = {}
            
                        
            if not resourceAttributes == None:
                _newattr_, rc = parse_json_string(resourceAttributes) 
            
            #if placeHolder:                
            #    _newattr_["isPlaceholder"] = "true"
                
            
            
            if rc > 0:
                raise Exit(4, action + ": invalid jython string while parsing modify/update attributes")

            if string.lower(action) == "modify":
                for s in signatures.enum():
                    if  s.matched:
                        r = s.matchedTo[0]
                        logit ("The " + r.className + " object you try to create a already exist as " + r.displayName + " (" + r.guid + ").")
                    else:
                        # ensure that attributes for the class has been loaded
                        cdmclass(s._class,None)

                        _crtattr_, rc = parse_json_string(s.json)
                                                
                        for n in _newattr_:
                            _crtattr_[n] = _newattr_[n] 
                        
                        for c in _crtattr_:
                            modification(s, attributes.find(c), _crtattr_[c] , False, "create")

                
            # check if it has already been found
                
            if not resourceType == None:
                _str_, rc = parse_json_string(resourceAttributes + ',"_class":"' + resourceType + '"')
                if rc > 0:
                    raise Exit(4, action + ": invalid jython string while parsing attr/export attributes")
                    
                    
                    
            for r in resources.enum():
                                
                unknown = []
                
                c = r._class
                _attributeNames_ = c.get_attributeNames()
                
                
                for _a_ in _newattr_:
             
                    if not _a_ in _attributeNames_:
                        unknown.append(_a_)  
                    
                if len(unknown) > 0:
                    for _a_ in unknown:
                        raise Exit(8, "Attribute '" + _a_ + "' is not valid for a " + r.className + " object.") 

                else:
                    for _a_ in _newattr_:    
                        ignore = False

                        _newVal_ = _newattr_[_a_]
                        ##########################
                        if len(_newVal_) > 0:
                            if _newVal_[0] == "=":
                                _ref_ = _newVal_[1:]
                                if _newattr_.has_key(_ref_):
                                    _newVal_ = _newattr_[_ref_]
                                elif r.values.has_key(_ref_):
                                    _newVal_ = r.values[_ref_]
                                else:
                                    raise Exit(8, "Invalid attribute reference " + str(_ref_) + " found in the " + str(_a_) + "attribute.")

                        if _a_ in attributesIgnore:
                            ignore = True

                        _oldVal_ = ""
                        _task_ = "modify"
                        if r.values.has_key(_a_):
                            _oldVal_ = r.get_values(_a_)
                            _task_ = "update"
                        if not _oldVal_ == _newVal_:                        
                            m = modification(r, attributes.find(_a_), _newVal_, ignore, _task_)
                                     
            
            if modifications.count() == 0:
                if action == "modify":
                    logit("There were no modifications to process")
                else:
                    logit("There were no " + action +"s to process")
                raise Exit(0)
            
            rc = list_modifications()

            if not rc == 0:
                raise Exit(rc)

            for _u_ in updates.enum():
                _data_ = _u_.resource.values

                for _d_ in _u_.attrib:
                    
                    if not (_d_ in ["guid", "_class", "type"]):
                        _data_[_d_] = string.strip(_u_.attrib[_d_], '"')
                
                _upd_ = {}    
                for _d_ in _data_:
                    if not (_d_ in ["guid",  "type"]):
                        if len(_data_[_d_]) > 0 and not _data_[_d_][0] in ["[","{"]:
                            ##lastModifiedBy
                            #print "@@@@@@@@@@ " + _d_ +":" +  _data_[_d_]
                            _upd_[_d_] = _data_[_d_]

                if not _data_.has_key("displayName"):
                    _upd_["displayName"]= "<unknown>"
                    
                #===================================================
                # add original values to ensure that naming rules are supported
                                
                rr = resources.find(_u_._instanceName_)
                    
                for oval in rr.values.keys():
                    #print oval
                    #print rr.values[oval]
                    if not oval in _upd_.keys() and oval not in ["lastModifiedTime"]:
                        #print str(oval) + ":" + str(rr.values[oval])
                        _upd_[oval] = rr.values[oval] 
                
                #===================================================
                            
                if force:
                    doit = "y"
                else:    
                    doit = ""    
                    while not doit == "y":
                        
                        q = "\nAre you sure that you wish to " + str(_u_.modification.task)
                        if _u_.modification.task == "create":
                            #answer = "y"
                            answer = raw_input( q + " a new " + str(_u_.modification.resource._class) + " identified by '" + str(_u_.attrib) + "'? (y(es)/n(o)/a(ll)/N(one)) ")
                        else:
                            answer = raw_input(q + " the value of the '" + str(_u_.attrib.keys()) + "' attribute(s) for the "  + str(_u_.modification.resource._class.name) + " '" + _data_["displayName"] + "' to '" + str(_u_.attrib.values()) + "'? (y(es)/n(o)/a(ll)/N(one)) ")
                        
                        if str(answer).lower() == "a":
                            doit = "y" 
                            force = True
                            answer = "y"
                        if str(answer) == "N":
                            raise Exit (4, "The " + action + " operation of all remaining resources has been cancelled.")                    
                        if not str(answer) == "":
                            doit = string.lower(answer[0])
                        if doit == "n":
                            break
                        
                if doit == "y":

                    if _u_.modification.task == "create":
                        _upd_["_class"] = str(_u_.modification.resource._class)
                        logit("\t" + _u_.modification.task + "ing a new " + str(_u_.modification.resource._class))
                        rc, res = resource_create(str(_u_.modification.resource._class), _upd_,False)                    
                    
                    else:
                        ## MMMMMMMMMMMMMMMMMMMMMMMMM
                        placeHolderSet = False
                        omitList =["bidiflag","lastModifiedTime","lastModifiedBy","displayName","createdBy"]
                        #omitList=[]
                        ##typeList =["String","long","int","None", "BindAddress"]
                        ##typeList=[]
                        keyList = _upd_.keys()
                        for _key_ in keyList:
                            ##print "+++++++   _key_: " + _key_
                            att =  attributes.find(_key_)
                            ##if att == None:
                            ##    att_type = "None"
                            ##else:    
                            ##att_type= att.gettype()
                            ##    att_str = string.split(att_type,".") 
                            ##
                            ##    if len(att_str) > 1:
                            ##        att_type = att_str[len(att_str)-1] 
                            #print "+++++++++++++ " + att_type + "      _key_: " + _key_ + "        " + _upd_[_key_]
                            #if _key_ in omitList or not att_type in typeList:
                            if _key_ in omitList:
                                #print "+++++++   omitting: (" + att_type + ") " + _key_
                                del _upd_[_key_]
                            #if _key_ == "isPlaceholder":
                            #    placeHolderSet = True;
                        ## add placeholder and ManagedSystemName       
                        #print "##########    Placeholder is: " + str(placeHolder) 
                        #print "##########    PlaceholderSet is: " + str(placeHolderSet) 
                        if placeHolder: 
                            _upd_["isPlaceholder"] = "true"     
                        ##print "##########    isPlaceholder: " + str(_upd_["isPlaceholder"]) 

                                  
                        ## MMMMMMMMMMMMMMMMMMMMMMMMM
                        logit("\t" + _u_.modification.task + "ing " + _u_.resource.className + " " + _u_.resource.name + " (" + _u_.resource.guid + ").")
                        rc, res = resource_update(_u_.guid, _u_.resource.className, _upd_)
                
                    if not rc == 0:
                        raise Exit(rc, "Error encountered during resource update: " + str(res))                        
                        
            
        else:

            #############################
            #############################
            #
            #  unknown action
            #
            #############################
            #############################     
            
            raise Exit(4, "Unknown action: '" + action + "'\nPlease choose one of : attr, create, delete, list, modify, update")

        raise Exit(0)



    except Exit, exit_ex:
              
        _name_ = "exit_ex"
        traceit("..." + _name_)
        exit_ex.printIt()
        exit_ex.leave()

    
    except SystemExit,sys_ex:
        closeFiles()
        sys.exit()
    
    except:
        _name_ = "main_except"
        traceit("..." + _name_)
        
        print "Fatal Error: " + str(sys.exc_info()[0]) + " " + str(sys.exc_info()[1])

        if not string.find(str(sys.exc_info()[0]), "Exit"):
            print >> sys.stderr, "Unexpected error: ", sys.exc_info()[0], sys.exc_info()[1]
        
        closeFiles()
        #sys.exit(main())                
        sys.exit()
        




tracer = None
# tracer = trace.Trace(ignoredirs=[sys.prefix, sys.exec_prefix], trace=1, count=2)


if __name__ == "__main__":
    if not tracer == None:
        sys.exit(tracer.run('main()'))
    else:    
        sys.exit(main())
